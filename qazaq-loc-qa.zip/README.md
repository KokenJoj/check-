# Qazaq Loc QA — Grand Mobile × Decentrathon 6.0 (Кейс 02)

Автономный CLI-инструмент, гибридный анализатор (Rule-Based + LLM), интерактивный веб-стенд для тимлида/носителя языка и пайплайн контроля качества казахской (`kk`) и узбекской (`uz`) локализации Flutter `.arb` файлов для **Grand Mobile**.

---

## Состав репозитория (Что сдается)

| Файл / Директория | Назначение |
|---|---|
| `locqa/` | Исходный код пакета: анализатор 11 типов ошибок (`analyzer.py`), CLI (`cli.py`), генератор отчетов (`reporter.py`), автоисправление (`fixer.py`), транслитерация в латиницу (`translit.py`), валидатор Flutter (`validator.py`), гибридный LLM-модуль и калькулятор стоимости (`llm.py`), веб-стенд (`webapp.py`). |
| `glossary.csv` | Игровой глоссарий Grand Mobile (56 терминов на `ru, kk, uz, en`) с допустимыми вариантами и комментариями по сленгу игроков (`фракция`, `отбасы`, `Grand Coins`, `варн`, `мут`, `бан`, `фура` и др.). |
| `report.json` & `report.html` | Сгенерированные JSON и HTML отчеты со всеми 11 типами ошибок по схеме ТЗ. |
| `intl_kk_fixed.arb` | Исправленный казахский ARB-файл, валидный для `flutter gen-l10n`, с отметками `"reviewed_by_human": true`. |
| ` report_uz.json` & `intl_uz_fixed.arb` | Бонус: проверка и исправление узбекской локализации (`intl_uz.arb`). |
| `intl_kk_latin.arb` & `intl_kk_latin_report.json` | Бонус: транслитерация казахского ARB в официальную латиницу с проверкой переполнения длины кнопок. |
| `METHODOLOGY.md` | Подробное описание методологии поиска и исправления ошибок, работы с сингармонизмом аффиксов и расчет стоимости LLM. |
| `.github/workflows/locqa.yml` | Бонус: GitHub Action, автоматически проверяющий `.arb` файлы на каждый Pull Request. |
| `tests/test_locqa.py` | Unit-тесты всех 11 детекторов, валидатора `flutter gen-l10n`, латиницы, узбекского языка и CLI. |

---

## Быстрый старт (Для Тимлида и Жюри)

### 1. Установка

```bash
pip install -e .
```

### 2. Обязательная CLI-команда из ТЗ

```bash
locqa check --source samples/intl_ru.arb --target samples/intl_kk.arb --glossary glossary.csv --out report.json
```

### 3. Пакетный запуск на архиве хакатона (`hack-4e892c51-sharkmove.zip`) одной командой

Положите архив `hack-4e892c51-sharkmove.zip` (или папку с распакованными `intl_ru.arb`, `intl_kk.arb`, `intl_uz.arb`) рядом и выполните:

```bash
locqa pipeline --input hack-4e892c51-sharkmove.zip --glossary glossary.csv --out-dir ./output
```

Команда автоматически распакует архив и создаст в `./output`:
- `report.json` и `report.html` (казахский отчет);
- `intl_kk_fixed.arb` (исправленный казахский файл с `reviewed_by_human: true`);
- `report_uz.json`, `report_uz.html`, `intl_uz_fixed.arb` (бонус: узбекский язык);
- `intl_kk_latin.arb` и `intl_kk_latin_report.json` (бонус: официальная казахская латиница + контроль длины);
- `metrics_summary.json` (валидация `flutter gen-l10n` и расчет стоимости токенов LLM).

### 4. Отдельные команды CLI

```bash
# Генерация исправленного ARB-файла
locqa fix --source samples/intl_ru.arb --target samples/intl_kk.arb --glossary glossary.csv --out intl_kk_fixed.arb

# Валидация совместимости с flutter gen-l10n и флагов reviewed_by_human
locqa validate --source samples/intl_ru.arb --fixed intl_kk_fixed.arb --original samples/intl_kk.arb

# Транслитерация в казахскую латиницу с проверкой длины кнопок
locqa translit --source samples/intl_ru.arb --target intl_kk_fixed.arb --out intl_kk_latin_report.json --arb-out intl_kk_latin.arb
```

### 5. Интерактивный веб-стенд для ревью и редактирования

```bash
python3 -m locqa.webapp 43123
```

Откройте `http://127.0.0.1:43123` — тимлид и носитель языка могут:
- фильтровать ошибки по всем 11 типам и уровням `severity`;
- **редактировать `suggestion` прямо в таблице** и нажимать **«Сохранить правки в файлы репо»** (обновляет `report.json`, `report.html` и `intl_kk_fixed.arb` на диске);
- загружать собственные `.arb` файлы через кнопку выбора файла.
