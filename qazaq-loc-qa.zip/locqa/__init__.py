"""Qazaq Loc QA — Localization QA Engine for Flutter ARB files."""

__version__ = "1.0.0"
