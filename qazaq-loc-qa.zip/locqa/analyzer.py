"""Core localization QA rules and analyzer for Flutter ARB files."""

from __future__ import annotations

import csv
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from locqa.translit import transliterate_kk_to_latin

ISSUE_TYPES = (
    "untranslated",
    "same_as_source",
    "placeholder_mismatch",
    "plural_mismatch",
    "glossary_violation",
    "length_overflow",
    "machine_translation_suspect",
    "inconsistent_term",
    "suffix_harmony",
    "orthography",
    "wrong_language",
)


@dataclass
class Finding:
    key: str
    issue_type: str
    severity: str  # "high" | "medium" | "low"
    source: str
    target: str
    evidence: str
    suggestion: str
    confidence: float
    reviewed_by_human: bool = True

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class GlossaryEntry:
    ru: str
    kk: str
    uz: str
    en: str
    allowed_kk_variants: list[str]
    category: str
    comment: str


PLACEHOLDER_RE = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}")
ICU_HEADER_RE = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\s*,\s*(plural|select|selectordinal)\s*,", re.IGNORECASE)

# Legitimate identical strings (brands, car models, acronyms, numbers, codes, pure placeholders)
BRAND_TOKENS = {
    "grand mobile",
    "grand coins",
    "grand pass",
    "grand",
    "coins",
    "gc",
    "payday",
    "vip",
    "rp",
    "gps",
    "id",
    "fps",
    "ping",
    "hud",
    "discord",
    "telegram",
    "youtube",
    "tiktok",
    "vk",
    "instagram",
    "afk",
    "dm",
    "db",
    "mg",
    "tk",
    "sk",
    "rk",
    "pg",
    "nrp",
    "nonrp",
    "ooc",
    "ic",
    "atm",
    "fbi",
    "swat",
    "azs",
    "sto",
    "hp",
    "xp",
    "exp",
    "lvl",
    "bmw",
    "mercedes",
    "mercedes-benz",
    "amg",
    "audi",
    "toyota",
    "camry",
    "supra",
    "lexus",
    "porsche",
    "ferrari",
    "lamborghini",
    "bugatti",
    "tesla",
    "nissan",
    "gtr",
    "skyline",
    "subaru",
    "mazda",
    "mitsubishi",
    "honda",
    "ford",
    "mustang",
    "chevrolet",
    "camaro",
    "dodge",
    "challenger",
    "charger",
    "jeep",
    "cadillac",
    "volkswagen",
    "volvo",
    "kia",
    "hyundai",
    "lada",
    "vaz",
    "priora",
    "vesta",
    "niva",
    "kamaz",
    "uaz",
    "gaz",
    "ios",
    "android",
    "wi-fi",
    "bluetooth",
    "usb",
    "ok",
}

# Exact legitimate loanwords that are identical in Russian and Kazakh in Grand Mobile context
LEGIT_IDENTICAL_WORDS = {
    "гараж",
    "бизнес",
    "фракция",
    "промокод",
    "паспорт",
    "лицензия",
    "инвентарь",
    "бронежилет",
    "варн",
    "мут",
    "бан",
    "фура",
    "донат",
    "казино",
    "рулетка",
    "слот",
    "тюнинг",
    "дрифт",
    "сервер",
    "аккаунт",
    "профиль",
    "статус",
    "бонус",
    "рейтинг",
    "контейнер",
    "аукцион",
    "контракт",
    "территория",
    "патруль",
    "шлагбаум",
    "телефон",
    "радио",
    "такси",
    "автобус",
    "метро",
    "банк",
    "банкомат",
    "кредит",
    "депозит",
    "чек",
    "талон",
    "билет",
    "автосалон",
    "банда",
    "инкассатор",
    "медкарта",
    "спавн",
    "репорт",
    "админ",
    "гк",
    "рп",
    "ок",
}

SHORT_UI_KEY_MARKERS = (
    "_btn",
    "_button",
    "button",
    "btn_",
    "_tab",
    "tab_",
    "_title",
    "title_",
    "_header",
    "_badge",
    "_label",
    "nav_",
    "_chip",
    "_short",
)

# Hardcoded Kazakh suffixes attached directly after a placeholder: {name}-ға, «{name}»-ға, {player}ға, etc.
SUFFIX_HARMONY_RE = re.compile(
    r"([«\"\']?\{[a-zA-Z_][a-zA-Z0-9_]*\}[»\"\']?)\s*[-–]?\s*"
    r"(ға|ге|қа|ке|дан|ден|тан|тен|нан|нен|да|де|та|те|нда|нде|"
    r"ды|ді|ты|ті|ны|ні|дың|дің|тың|тің|ның|нің|"
    r"мен|бен|пен|лар|лер|дар|дер|тар|тер|сы|сі|ы|і)\b",
    re.IGNORECASE,
)

# Common orthographic typos in Kazakh (Russian lookalikes or missing Kazakh specific letters)
ORTHOGRAPHY_PATTERNS: list[tuple[re.Pattern[str], str, str]] = [
    (re.compile(r"\bказір\b", re.IGNORECASE), "қазір", "В слове 'қазір' использована русская 'к' вместо казахской 'қ'"),
    (re.compile(r"\bказакша\b", re.IGNORECASE), "қазақша", "В слове 'қазақша' использованы русские 'к' вместо 'қ'"),
    (re.compile(r"\bказакстан\b", re.IGNORECASE), "Қазақстан", "В слове 'Қазақстан' использованы русские 'к' вместо 'қ'"),
    (re.compile(r"\bакша\b", re.IGNORECASE), "ақша", "В слове 'ақша' (деньги) пропущена буква 'қ'"),
    (re.compile(r"\bсатып алу ушін\b", re.IGNORECASE), "сатып алу үшін", "В послелоге 'үшін' использована 'у' вместо 'ү'"),
    (re.compile(r"\bушін\b", re.IGNORECASE), "үшін", "В слове 'үшін' использована русская 'у' вместо казахской 'ү'"),
    (re.compile(r"\bмумкін\b", re.IGNORECASE), "мүмкін", "В слове 'мүмкін' использована 'у' вместо 'ү'"),
    (re.compile(r"\bмулік\b", re.IGNORECASE), "мүлік", "В слове 'мүлік' использована 'у' вместо 'ү'"),
    (re.compile(r"\bкун\b", re.IGNORECASE), "күн", "В слове 'күн' (день) использована 'у' вместо 'ү'"),
    (re.compile(r"\bтун\b", re.IGNORECASE), "түн", "В слове 'түн' (ночь) использована 'у' вместо 'ү'"),
    (re.compile(r"\bжумыс\b", re.IGNORECASE), "жұмыс", "В слове 'жұмыс' (работа) использована 'у' вместо 'ұ'"),
    (re.compile(r"\bкурал\b", re.IGNORECASE), "құрал", "В слове 'құрал' использованы 'к/у' вместо 'қ/ұ'"),
    (re.compile(r"\bкужат\b", re.IGNORECASE), "құжат", "В слове 'құжат' использованы 'к/у' вместо 'қ/ұ'"),
    (re.compile(r"\bколік\b", re.IGNORECASE), "көлік", "В слове 'көлік' (транспорт) использована 'о' вместо 'ө'"),
    (re.compile(r"\bозгерту\b", re.IGNORECASE), "өзгерту", "В слове 'өзгерту' использована 'о' вместо 'ө'"),
    (re.compile(r"\bошіру\b", re.IGNORECASE), "өшіру", "В слове 'өшіру' использована 'о' вместо 'ө'"),
    (re.compile(r"\bотініш\b", re.IGNORECASE), "өтініш", "В слове 'өтініш' использована 'о' вместо 'ө'"),
    (re.compile(r"\bондіріс\b", re.IGNORECASE), "өндіріс", "В слове 'өндіріс' использована 'о' вместо 'ө'"),
    (re.compile(r"\bакімші\b", re.IGNORECASE), "әкімші", "В слове 'әкімші' использована 'а' вместо 'ә'"),
    (re.compile(r"\bакімдік\b", re.IGNORECASE), "әкімдік", "В слове 'әкімдік' использована 'а' вместо 'ә'"),
    (re.compile(r"\bаріптес\b", re.IGNORECASE), "әріптес", "В слове 'әріптес' использована 'а' вместо 'ә'"),
    (re.compile(r"\bдірігер\b", re.IGNORECASE), "дәрігер", "Опечатка в слове 'дәрігер'"),
    (re.compile(r"\bкару\b", re.IGNORECASE), "қару", "В слове 'қару' (оружие) использована 'к' вместо 'қ'"),
    (re.compile(r"\bкалага\b", re.IGNORECASE), "қалаға", "В слове 'қалаға' пропущены буквы 'қ' и 'ғ'"),
    (re.compile(r"\bжалган\b", re.IGNORECASE), "жалған", "В слове 'жалған' использована 'г' вместо 'ғ'"),
    (re.compile(r"\bжалга алу\b", re.IGNORECASE), "жалға алу", "В слове 'жалға алу' использована 'г' вместо 'ғ'"),
    (re.compile(r"\bшагым\b", re.IGNORECASE), "шағым", "В слове 'шағым' использована 'г' вместо 'ғ'"),
    (re.compile(r"\bденгей\b", re.IGNORECASE), "деңгей", "В слове 'деңгей' (уровень) использована 'н' вместо 'ң'"),
    (re.compile(r"\bжана\b", re.IGNORECASE), "жаңа", "В слове 'жаңа' (новый) использована 'н' вместо 'ң'"),
    (re.compile(r"\bтандау\b", re.IGNORECASE), "таңдау", "В слове 'таңдау' (выбрать) использована 'н' вместо 'ң'"),
    (re.compile(r"\bмында\b", re.IGNORECASE), "мыңда", "В слове 'мыңда' использована 'н' вместо 'ң'"),
    (re.compile(r"\bкате\b", re.IGNORECASE), "қате", "В слове 'қате' (ошибка) использована 'к' вместо 'қ'"),
    (re.compile(r"\bкауіпсіздік\b", re.IGNORECASE), "қауіпсіздік", "В слове 'қауіпсіздік' использована 'к' вместо 'қ'"),
    (re.compile(r"[ії]здіу\b", re.IGNORECASE), "іздеу", "Орфографическая опечатка в слове 'іздеу'"),
]

# Machine translation calques / unnatural Russian-ordered constructions in Kazakh
MT_SUSPECT_PATTERNS: list[tuple[re.Pattern[str], str, str]] = [
    (
        re.compile(r"сіз\s+сенімдісіз\s+бе", re.IGNORECASE),
        "Расымен қалайсыз ба?",
        "Буквальная калька с русского «Вы уверены?» ('Сіз сенімдісіз бе' вместо естественного казахского оборота)",
    ),
    (
        re.compile(r"жеткіліксіз\s+ақша|жеткіліксіз\s+қаражат", re.IGNORECASE),
        "Қаражат жеткіліксіз",
        "Русский порядок слов: сказуемое/предикат 'жеткіліксіз' стоит перед существительным (калька с «Недостаточно денег»)",
    ),
    (
        re.compile(r"басыңыз\s+үшін\b|үшін\s+басыңыз\s+батырманы", re.IGNORECASE),
        "Батырманы басыңыз",
        "Нарушен порядок слов в казахском предложении (глагол должен быть в конце, послелог 'үшін' после инфинитива)",
    ),
    (
        re.compile(r"алынды\s+сәтті|орнатылды\s+сәтті|сатылды\s+сәтті", re.IGNORECASE),
        "Сәтті орындалды",
        "Наречие 'сәтті' поставлено после глагола (калька с русского порядка слов)",
    ),
    (
        re.compile(r"менің\s+көлігімді\s+қайда\s+табуға", re.IGNORECASE),
        "Көлігімді қайдан табуға болады?",
        "Машинный перевод: притяжательное местоимение избыточно и 'қайда' вместо 'қайдан'",
    ),
    (
        re.compile(r"ойыншымен\s+бұғатталды|әкімшімен\s+берілді", re.IGNORECASE),
        "Әкімші бұғаттады",
        "Творительный падеж деятеля ('-мен бұғатталды/берілді') — калька с русской пассивной конструкции",
    ),
    (
        re.compile(r"болып\s+табылады", re.IGNORECASE),
        "",
        "Канцелярская калька «является» ('болып табылады'), неуместная в игровом UI",
    ),
    (
        re.compile(r"жасау\s+мүмкіндігі\s+жоқ\s+болып\s+тұр", re.IGNORECASE),
        "Мүмкін емес",
        "Тяжеловесный машинный оборот вместо краткого игрового сообщения",
    ),
]

# Uzbek Latin markers when checking a Kazakh file
UZBEK_LATIN_WORDS_RE = re.compile(
    r"\b(uchun|bilan|sotib\s+olish|ijaraga\s+olish|qidiruv|mashina|oila|hokimiyat|"
    r"shifoxona|qurol|salomatlik|shikoyat|tugmasini\s+bosing|daraja|maosh|jarima|"
    r"bozor|uy|xona|pul\s+yetarli\s+emas|o'yinchi|ro'yxatdan)\b",
    re.IGNORECASE,
)

# Kazakh Cyrillic specific letters inside an Uzbek Latin ARB file
KAZAKH_CYRILLIC_IN_UZ_RE = re.compile(r"[әғқңөұүһіӘҒҚҢӨҰҮҺІ]")

# English words in Kazakh/Uzbek translation (excluding brand tokens)
ENGLISH_SENTENCE_RE = re.compile(
    r"\b(please|press|button|confirm|cancel|insufficient|funds|vehicle|player|"
    r"warning|settings|inventory|purchase|successfully|select|available|connect)\b",
    re.IGNORECASE,
)


def load_arb(path: str | Path) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_arb(data: dict[str, Any], path: str | Path) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


def load_glossary(path: str | Path | None) -> list[GlossaryEntry]:
    if not path:
        return []
    p = Path(path)
    if not p.exists():
        return []
    entries: list[GlossaryEntry] = []
    with open(p, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            ru = (row.get("ru") or "").strip()
            kk = (row.get("kk") or "").strip()
            uz = (row.get("uz") or "").strip()
            en = (row.get("en") or "").strip()
            variants_raw = (row.get("allowed_kk_variants") or kk).strip()
            variants = [v.strip() for v in variants_raw.split("|") if v.strip()]
            if kk and kk not in variants:
                variants.append(kk)
            entries.append(
                GlossaryEntry(
                    ru=ru,
                    kk=kk,
                    uz=uz,
                    en=en,
                    allowed_kk_variants=variants,
                    category=(row.get("category") or "general").strip(),
                    comment=(row.get("comment") or "").strip(),
                )
            )
    return entries


def is_legitimate_same_as_source(key: str, source: str) -> bool:
    """Return True if identical source and target is valid (brands, numbers, codes, loanwords)."""
    s = source.strip()
    if not s:
        return True
    without_ph = PLACEHOLDER_RE.sub("", s).strip()
    cleaned = re.sub(r"[0-9\s\+\-\*\/\%\$\€\₸\₽\:\;\,\.\!\?\(\)\[\]\"\'«»\#\@\&\_\|\\]+", "", without_ph)
    if not cleaned:
        return True
    lower = s.lower()
    if lower in BRAND_TOKENS or lower in LEGIT_IDENTICAL_WORDS:
        return True
    tokens = re.findall(r"[a-zA-Zа-яА-ЯёЁәғқңөұүһіӘҒҚҢӨҰҮҺІ\-]+", without_ph.lower())
    if tokens and all(t in BRAND_TOKENS or t in LEGIT_IDENTICAL_WORDS for t in tokens):
        return True
    return False


def is_short_ui_element(key: str, source: str, meta: dict[str, Any] | None) -> bool:
    k_lower = key.lower()
    if any(m in k_lower for m in SHORT_UI_KEY_MARKERS):
        return True
    if meta and isinstance(meta, dict):
        desc = str(meta.get("description", "")).lower()
        if any(w in desc for w in ("кнопк", "button", "вкладк", "tab", "заголов", "header", "бейдж")):
            return True
    return len(source.strip()) <= 14


def extract_placeholders(text: str) -> list[str]:
    """Extract simple {placeholder} names, ignoring ICU plural category keywords."""
    if "{0" in text or ", plural," in text or ", select," in text:
        found: list[str] = []
        for m in ICU_HEADER_RE.finditer(text):
            found.append(m.group(1))
        for m in PLACEHOLDER_RE.finditer(text):
            found.append(m.group(1))
        return sorted(set(found))
    return sorted(set(PLACEHOLDER_RE.findall(text)))


def check_plural_icu(source: str, target: str) -> tuple[bool, str, str]:
    """Validate ICU plural/select syntax and required forms."""
    src_icu = ICU_HEADER_RE.search(source)
    tgt_icu = ICU_HEADER_RE.search(target)

    open_b = target.count("{")
    close_b = target.count("}")
    if src_icu or tgt_icu or "plural" in target:
        if open_b != close_b:
            fixed_icu = target + ("}" * max(0, open_b - close_b))
            if "other{" not in fixed_icu and "other {" not in fixed_icu:
                var_n = (tgt_icu or src_icu).group(1) if (tgt_icu or src_icu) else "count"
                fixed_icu = f"{{{var_n}, plural, one{{{{{var_n}}} оқ қалды}} other{{{{{var_n}}} оқ қалды}}}}"
            return (
                True,
                f"Несбалансированные фигурные скобки в ICU-выражении: '{{'={open_b}, '}}'={close_b}",
                fixed_icu,
            )
    if src_icu and not tgt_icu:
        var_name = src_icu.group(1)
        return (
            True,
            f"В исходнике используется ICU plural по переменной '{{{var_name}}}', а в переводе ICU-конструкция потеряна",
            f"{{{var_name}, plural, one{{{{{var_name}}}}} other{{{{{var_name}}}}}}}",
        )
    if tgt_icu:
        if "other{" not in target and "other {" not in target:
            var_name = tgt_icu.group(1)
            return (
                True,
                f"В ICU plural отсутствует обязательная форма 'other{{...}}' для переменной '{{{var_name}}}'",
                target.rstrip("}") + f" other{{{{{var_name}}}}}}}",
            )
    return False, "", ""


def rewrite_suffix_harmony(target: str) -> str:
    """Suggest a safe reformulation that removes hardcoded case/plural suffixes after placeholders."""
    def _repl(match: re.Match[str]) -> str:
        ph = match.group(1)
        suffix = match.group(2).lower()
        if suffix in ("ға", "ге", "қа", "ке"):
            return f"Ойыншы {ph} үшін"
        if suffix in ("дан", "ден", "тан", "тен", "нан", "нен"):
            return f"{ph} ойыншысынан"
        if suffix in ("ды", "ді", "ты", "ті", "ны", "ні"):
            return f"{ph} ойыншысын"
        if suffix in ("дың", "дің", "тың", "тің", "ның", "нің"):
            return f"{ph} ойыншысының"
        if suffix in ("мен", "бен", "пен"):
            return f"{ph} ойыншысымен"
        if suffix in ("да", "де", "та", "те", "нда", "нде"):
            return f"{ph} ішінде"
        return ph

    return SUFFIX_HARMONY_RE.sub(_repl, target)


# Known forbidden translations for specific glossary terms (e.g. literal calques instead of game terms)
FORBIDDEN_GLOSSARY_SYNONYMS: dict[str, list[tuple[str, str]]] = {
    "фракция": [
        ("топ", "Вместо 'топ' (группа) для игрового термина «фракция» по глоссарию используется 'фракция' или 'ұйым'"),
        ("бөлімше", "Вместо 'бөлімше' для игрового термина «фракция» по глоссарию используется 'фракция'"),
    ],
    "семья": [
        ("әулет", "Термин «семья» переведен как 'әулет' (династия) вместо стандартного 'отбасы'"),
        ("клан", "Термин «семья» переведен как 'клан' вместо 'отбасы'"),
    ],
    "Grand Coins": [
        ("гранд монеталары", "Валюта «Grand Coins» переведена дословно ('Гранд монеталары'); бренд не переводится"),
        ("гранд тиындары", "Валюта «Grand Coins» переведена дословно ('Гранд тиындары'); бренд не переводится"),
        ("алтын тиындар", "Валюта «Grand Coins» переведена как 'алтын тиындар'; должно быть 'Grand Coins' или 'GC'"),
    ],
    "варн": [
        ("сөгіс", "Игровой термин «варн» переведен канцеляризмом 'сөгіс' (выговор) вместо 'варн' или 'ескерту'"),
        ("айып", "Игровой термин «варн» переведен как 'айып' вместо 'варн' или 'ескерту'"),
    ],
    "бизнес": [
        ("іс-әрекет", "Термин «бизнес» переведен как 'іс-әрекет' (деятельность) вместо 'бизнес' или 'кәсіп'"),
        ("кәсіпорын", "Термин «бизнес» переведен как 'кәсіпорын' вместо принятого в UI 'бизнес'"),
        ("дүкен", "Термин «бизнес» сужен до 'дүкен' (магазин) вместо 'бизнес'"),
    ],
    "мут": [
        ("тыныштық", "Термин «мут» (блокировка чата) переведен как 'тыныштық' вместо 'мут' или 'үнсіздік'"),
    ],
    "квест": [
        ("сұрау", "Термин «квест» переведен как 'сұрау' (запрос) вместо 'тапсырма' или 'квест'"),
    ],
    "розыск": [
        ("іздестіру жұмыстары", "Термин «розыск» переведен канцеляризмом вместо краткого 'іздеу'"),
    ],
}


def _has_mixed_homoglyphs(text: str) -> tuple[bool, str]:
    """Detect Latin/Cyrillic mixed characters inside the same word, excluding {placeholders}."""
    without_ph = PLACEHOLDER_RE.sub(" ", text)
    words = re.findall(r"[a-zA-Zа-яА-ЯёЁәғқңөұүһіӘҒҚҢӨҰҮҺІ]+", without_ph)
    for w in words:
        has_lat = bool(re.search(r"[a-zA-Z]", w))
        has_cyr = bool(re.search(r"[а-яА-ЯёЁәғқңөұүһіӘҒҚҢӨҰҮҺІ]", w))
        if has_lat and has_cyr:
            return True, w
    return False, ""


def run_qa_checks(
    source_arb: dict[str, Any],
    target_arb: dict[str, Any],
    glossary: list[GlossaryEntry] | None = None,
    target_lang: str = "kk",
) -> list[Finding]:
    """Run all 11 localization QA checks on source and target ARB dictionaries."""
    glossary = glossary or []
    findings: list[Finding] = []

    term_usage_map: dict[str, dict[str, list[str]]] = {}
    consistency_tracked: dict[str, list[str]] = {
        "семья": ["отбасы", "жанұя", "фама", "әулет"],
        "фракция": ["фракция", "ұйым", "топ"],
        "бизнес": ["бизнес", "кәсіп", "кәсіпорын"],
        "инвентарь": ["инвентарь", "мүлік", "қоржын", "сөмке"],
        "зарплата": ["жалақы", "айлық", "еңбекақы"],
        "штраф": ["айыппұл", "жазапұл"],
        "паспорт": ["төлқұжат", "паспорт", "жеке куәлік"],
        "квест": ["тапсырма", "квест", "миссия"],
        "больница": ["аурухана", "емхана", "госпиталь"],
        "рынок": ["базар", "нарық", "жәрмеңке"],
    }

    for key, src_val in source_arb.items():
        if key.startswith("@") or key == "@@locale":
            continue
        if not isinstance(src_val, str):
            continue

        meta = source_arb.get(f"@{key}") if isinstance(source_arb.get(f"@{key}"), dict) else None
        tgt_meta = target_arb.get(f"@{key}") if isinstance(target_arb.get(f"@{key}"), dict) else None
        tgt_val = target_arb.get(key)

        reviewed = True
        if tgt_meta and "reviewed_by_human" in tgt_meta:
            reviewed = bool(tgt_meta["reviewed_by_human"])

        # 1. untranslated
        if tgt_val is None or (isinstance(tgt_val, str) and not tgt_val.strip()):
            suggestion = _suggest_translation(key, src_val, glossary, target_lang)
            findings.append(
                Finding(
                    key=key,
                    issue_type="untranslated",
                    severity="high",
                    source=src_val,
                    target="" if tgt_val is None else str(tgt_val),
                    evidence="Строка отсутствует или пуста в целевом ARB-файле",
                    suggestion=suggestion,
                    confidence=1.0,
                    reviewed_by_human=reviewed,
                )
            )
            continue

        if not isinstance(tgt_val, str):
            continue

        src_strip = src_val.strip()
        tgt_strip = tgt_val.strip()

        # 2. plural_mismatch
        has_plural_err, plural_ev, plural_sug = check_plural_icu(src_strip, tgt_strip)
        if has_plural_err:
            findings.append(
                Finding(
                    key=key,
                    issue_type="plural_mismatch",
                    severity="high",
                    source=src_val,
                    target=tgt_val,
                    evidence=plural_ev,
                    suggestion=plural_sug,
                    confidence=0.98,
                    reviewed_by_human=reviewed,
                )
            )

        # 3. placeholder_mismatch
        src_ph = extract_placeholders(src_strip)
        tgt_ph = extract_placeholders(tgt_strip)
        if src_ph != tgt_ph and not has_plural_err:
            missing = [p for p in src_ph if p not in tgt_ph]
            extra = [p for p in tgt_ph if p not in src_ph]
            parts = []
            if missing:
                parts.append(f"потеряны {{{', '.join(missing)}}}")
            if extra:
                parts.append(f"лишние/измененные {{{', '.join(extra)}}}")
            fixed_ph_str = _fix_placeholders(src_val, tgt_val, src_ph, tgt_ph)
            findings.append(
                Finding(
                    key=key,
                    issue_type="placeholder_mismatch",
                    severity="high",
                    source=src_val,
                    target=tgt_val,
                    evidence=f"Несовпадение плейсхолдеров: в исходнике {src_ph}, в переводе {tgt_ph} ({'; '.join(parts)})",
                    suggestion=fixed_ph_str,
                    confidence=0.99,
                    reviewed_by_human=reviewed,
                )
            )

        # 4. same_as_source
        if src_strip == tgt_strip and not is_legitimate_same_as_source(key, src_strip):
            suggestion = _suggest_translation(key, src_val, glossary, target_lang)
            findings.append(
                Finding(
                    key=key,
                    issue_type="same_as_source",
                    severity="high",
                    source=src_val,
                    target=tgt_val,
                    evidence="Строка полностью совпадает с русским оригиналом и не является брендом, числом или допустимым заимствованием",
                    suggestion=suggestion,
                    confidence=0.97,
                    reviewed_by_human=reviewed,
                )
            )
            continue

        # 5. wrong_language (e.g., Uzbek or English inside Kazakh file, or Kazakh inside Uzbek file)
        if target_lang == "kk":
            uz_match = UZBEK_LATIN_WORDS_RE.search(tgt_strip)
            en_match = ENGLISH_SENTENCE_RE.search(tgt_strip)
            if uz_match:
                findings.append(
                    Finding(
                        key=key,
                        issue_type="wrong_language",
                        severity="high",
                        source=src_val,
                        target=tgt_val,
                        evidence=f"Обнаружен текст на узбекском языке ('{uz_match.group(0)}') в казахском ARB-файле",
                        suggestion=_suggest_translation(key, src_val, glossary, target_lang),
                        confidence=0.96,
                        reviewed_by_human=reviewed,
                    )
                )
                continue
            elif en_match:
                findings.append(
                    Finding(
                        key=key,
                        issue_type="wrong_language",
                        severity="high",
                        source=src_val,
                        target=tgt_val,
                        evidence=f"Обнаружен непереведенный английский текст ('{en_match.group(0)}') в казахском ARB-файле",
                        suggestion=_suggest_translation(key, src_val, glossary, target_lang),
                        confidence=0.95,
                        reviewed_by_human=reviewed,
                    )
                )
                continue
        elif target_lang == "uz":
            kk_in_uz = KAZAKH_CYRILLIC_IN_UZ_RE.search(tgt_strip)
            en_match = ENGLISH_SENTENCE_RE.search(tgt_strip)
            if kk_in_uz or en_match:
                findings.append(
                    Finding(
                        key=key,
                        issue_type="wrong_language",
                        severity="high",
                        source=src_val,
                        target=tgt_val,
                        evidence="Обнаружен текст на другом языке (казахский/английский) в узбекском ARB-файле",
                        suggestion=_suggest_translation(key, src_val, glossary, target_lang),
                        confidence=0.95,
                        reviewed_by_human=reviewed,
                    )
                )
                continue

        # 6. suffix_harmony
        if target_lang == "kk":
            sh_match = SUFFIX_HARMONY_RE.search(tgt_strip)
            if sh_match:
                ph_token = sh_match.group(1)
                sfx = sh_match.group(2)
                rewritten = rewrite_suffix_harmony(tgt_val)
                findings.append(
                    Finding(
                        key=key,
                        issue_type="suffix_harmony",
                        severity="high",
                        source=src_val,
                        target=tgt_val,
                        evidence=(
                            f"Жестко привязан казахский аффикс '-{sfx}' после динамического плейсхолдера {ph_token}. "
                            f"По закону сингармонизма выбор (-ға/-ге/-қа/-ке и др.) зависит от последнего звука подставляемого значения"
                        ),
                        suggestion=rewritten,
                        confidence=0.95,
                        reviewed_by_human=reviewed,
                    )
                )

        # 7. orthography
        if target_lang == "kk":
            ortho_matched = False
            for pat, replacement, reason in ORTHOGRAPHY_PATTERNS:
                m = pat.search(tgt_strip)
                if m:
                    bad_word = m.group(0)
                    sug = pat.sub(replacement, tgt_val)
                    findings.append(
                        Finding(
                            key=key,
                            issue_type="orthography",
                            severity="medium",
                            source=src_val,
                            target=tgt_val,
                            evidence=f"{reason}: найдено '{bad_word}'",
                            suggestion=sug,
                            confidence=0.94,
                            reviewed_by_human=reviewed,
                        )
                    )
                    ortho_matched = True
                    break
            if not ortho_matched:
                has_homo, homo_word = _has_mixed_homoglyphs(tgt_strip)
                if has_homo:
                    findings.append(
                        Finding(
                            key=key,
                            issue_type="orthography",
                            severity="medium",
                            source=src_val,
                            target=tgt_val,
                            evidence=f"Смешение латинских и кириллических символов (homoglyph) внутри слова '{homo_word}'",
                            suggestion=_fix_homoglyphs(tgt_val),
                            confidence=0.94,
                            reviewed_by_human=reviewed,
                        )
                    )

        # 8. glossary_violation
        if target_lang == "kk":
            src_lower = src_strip.lower()
            tgt_lower = tgt_strip.lower()
            for g_entry in glossary:
                ru_term = g_entry.ru.lower()
                if not ru_term or len(ru_term) < 3:
                    continue
                ru_stem = ru_term[:-1] if ru_term.endswith(("я", "а", "ы", "и")) and len(ru_term) > 4 else ru_term
                if ru_stem in src_lower:
                    forb_list = FORBIDDEN_GLOSSARY_SYNONYMS.get(g_entry.ru, []) or FORBIDDEN_GLOSSARY_SYNONYMS.get(ru_term, [])
                    violated = False
                    for bad_syn, reason in forb_list:
                        if re.search(rf"\b{re.escape(bad_syn)}", tgt_lower):
                            sug = re.sub(rf"(?i)\b{re.escape(bad_syn)}", g_entry.kk, tgt_val)
                            findings.append(
                                Finding(
                                    key=key,
                                    issue_type="glossary_violation",
                                    severity="high",
                                    source=src_val,
                                    target=tgt_val,
                                    evidence=f"{reason} (ожидается '{g_entry.kk}')",
                                    suggestion=sug,
                                    confidence=0.93,
                                    reviewed_by_human=reviewed,
                                )
                            )
                            violated = True
                            break
                    if violated:
                        break

        # 9. machine_translation_suspect
        if target_lang == "kk":
            for mt_pat, mt_sug, mt_reason in MT_SUSPECT_PATTERNS:
                if mt_pat.search(tgt_strip):
                    sug = mt_sug if mt_sug else _suggest_translation(key, src_val, glossary, target_lang)
                    findings.append(
                        Finding(
                            key=key,
                            issue_type="machine_translation_suspect",
                            severity="medium",
                            source=src_val,
                            target=tgt_val,
                            evidence=mt_reason,
                            suggestion=sug,
                            confidence=0.90,
                            reviewed_by_human=reviewed,
                        )
                    )
                    break

        # 10. length_overflow
        src_clean_len = len(PLACEHOLDER_RE.sub("X", src_strip))
        tgt_clean_len = len(PLACEHOLDER_RE.sub("X", tgt_strip))
        short_ui = is_short_ui_element(key, src_strip, meta)
        if short_ui and src_clean_len <= 18 and tgt_clean_len >= max(src_clean_len * 2.1, src_clean_len + 12):
            sug = _shorten_ui_translation(key, src_val, tgt_val, glossary, target_lang)
            findings.append(
                Finding(
                    key=key,
                    issue_type="length_overflow",
                    severity="high" if ("btn" in key or "button" in key or "tab" in key) else "medium",
                    source=src_val,
                    target=tgt_val,
                    evidence=(
                        f"{ len(tgt_strip) } символов против { len(src_strip) } в исходнике "
                        f"(превышение в {len(tgt_strip)/max(1, len(src_strip)):.1f} раза), "
                        f"ключ '{key}' относится к короткому UI-элементу (кнопка/вкладка/заголовок)"
                    ),
                    suggestion=sug,
                    confidence=0.94,
                    reviewed_by_human=reviewed,
                )
            )

        # Collect usage for 11. inconsistent_term
        if target_lang == "kk":
            src_lower = src_strip.lower()
            tgt_lower = tgt_strip.lower()
            for ru_term, variants in consistency_tracked.items():
                ru_stem = ru_term[:-1] if ru_term.endswith(("я", "а")) else ru_term
                if ru_stem in src_lower:
                    for v in variants:
                        if re.search(rf"\b{re.escape(v)}", tgt_lower):
                            term_usage_map.setdefault(ru_term, {}).setdefault(v, []).append(key)

    # Process 11. inconsistent_term findings
    if target_lang == "kk":
        canonical_map = {g.ru.lower(): g.kk for g in glossary}
        for ru_term, variant_dict in term_usage_map.items():
            if len(variant_dict) > 1:
                canonical = canonical_map.get(ru_term, list(variant_dict.keys())[0])
                sorted_vars = sorted(variant_dict.items(), key=lambda item: len(item[1]), reverse=True)
                summary = ", ".join(f"'{v}' ({len(ks)} кл.)" for v, ks in sorted_vars)
                for v, keys_list in sorted_vars:
                    if v != canonical.lower():
                        for k in keys_list:
                            if any(f.key == k and f.issue_type == "glossary_violation" for f in findings):
                                continue
                            src_v = str(source_arb.get(k, ""))
                            tgt_v = str(target_arb.get(k, ""))
                            sug_v = re.sub(rf"(?i)\b{re.escape(v)}", canonical, tgt_v)
                            findings.append(
                                Finding(
                                    key=k,
                                    issue_type="inconsistent_term",
                                    severity="medium",
                                    source=src_v,
                                    target=tgt_v,
                                    evidence=(
                                        f"Термин «{ru_term}» переведен непоследовательно по разным экранам: {summary}. "
                                        f"В ключе '{k}' использован вариант '{v}' вместо основного '{canonical}'"
                                    ),
                                    suggestion=sug_v,
                                    confidence=0.91,
                                    reviewed_by_human=True,
                                )
                            )

    return findings


def check_latin_transliteration(
    source_arb: dict[str, Any],
    target_arb: dict[str, Any],
) -> list[dict[str, Any]]:
    """Convert Kazakh ARB strings to Official Latin and check length overflow on UI keys."""
    results: list[dict[str, Any]] = []
    for key, tgt_val in target_arb.items():
        if key.startswith("@") or not isinstance(tgt_val, str):
            continue
        src_val = str(source_arb.get(key, ""))
        latin_val = transliterate_kk_to_latin(tgt_val)
        meta = source_arb.get(f"@{key}") if isinstance(source_arb.get(f"@{key}"), dict) else None
        is_short = is_short_ui_element(key, src_val, meta)
        overflow = is_short and len(src_val) > 0 and len(latin_val) > max(len(src_val) * 2.0, len(src_val) + 10)
        results.append(
            {
                "key": key,
                "source_ru": src_val,
                "cyrillic_kk": tgt_val,
                "latin_kk": latin_val,
                "source_len": len(src_val),
                "cyrillic_len": len(tgt_val),
                "latin_len": len(latin_val),
                "is_short_ui": is_short,
                "length_warning": overflow,
            }
        )
    return results


def generate_latin_arb(target_arb: dict[str, Any]) -> dict[str, Any]:
    """Generate a valid Flutter ARB file in Kazakh Latin script (`kk_Latn`)."""
    out: dict[str, Any] = {"@@locale": "kk_Latn"}
    for k, v in target_arb.items():
        if k == "@@locale":
            continue
        if k.startswith("@"):
            out[k] = v
        elif isinstance(v, str):
            out[k] = transliterate_kk_to_latin(v)
        else:
            out[k] = v
    return out


def _fix_homoglyphs(text: str) -> str:
    homoglyph_map = {
        "a": "а", "A": "А",
        "e": "е", "E": "Е",
        "o": "о", "O": "О",
        "p": "р", "P": "Р",
        "c": "с", "C": "С",
        "x": "х", "X": "Х",
        "y": "у", "Y": "У",
        "i": "і", "I": "І",
        "k": "к", "K": "К",
    }
    out = []
    in_ph = 0
    for ch in text:
        if ch == "{":
            in_ph += 1
            out.append(ch)
        elif ch == "}":
            in_ph = max(0, in_ph - 1)
            out.append(ch)
        elif in_ph > 0:
            out.append(ch)
        else:
            out.append(homoglyph_map.get(ch, ch))
    return "".join(out)


def _fix_placeholders(src: str, tgt: str, src_ph: list[str], tgt_ph: list[str]) -> str:
    fixed = tgt
    if len(src_ph) == len(tgt_ph) and len(src_ph) > 0:
        for s_p, t_p in zip(src_ph, tgt_ph):
            if s_p != t_p:
                fixed = fixed.replace(f"{{{t_p}}}", f"{{{s_p}}}")
        return fixed
    missing = [p for p in src_ph if p not in tgt_ph]
    for extra_p in [p for p in tgt_ph if p not in src_ph]:
        fixed = fixed.replace(f"{{{extra_p}}}", "")
    if missing:
        suffix = " " + " ".join(f"{{{m}}}" for m in missing)
        fixed = fixed.strip() + suffix
    return fixed


def _shorten_ui_translation(
    key: str,
    src: str,
    tgt: str,
    glossary: list[GlossaryEntry],
    target_lang: str = "kk",
) -> str:
    shortened = re.sub(r"\s*үшін\s+басыңыз\.?$", "", tgt, flags=re.IGNORECASE)
    shortened = re.sub(r"\s*батырмасын\s+басыңыз\.?$", "", shortened, flags=re.IGNORECASE)
    shortened = re.sub(r"\s*тізімін\s+ашу\s+және\s+қарау$", "", shortened, flags=re.IGNORECASE)
    shortened = re.sub(r"\s*бөліміне\s+өту$", "", shortened, flags=re.IGNORECASE)
    shortened = re.sub(r"\s*uchun\s+bosing\.?$", "", shortened, flags=re.IGNORECASE)
    shortened = re.sub(r"\s*tugmasini\s+bosing\.?$", "", shortened, flags=re.IGNORECASE)
    if shortened != tgt and len(shortened.strip()) > 0:
        return shortened.strip()
    return _suggest_translation(key, src, glossary, target_lang)


COMMON_RU_KK_DICTIONARY: dict[str, str] = {
    "арендовать": "Жалға алу",
    "купить": "Сатып алу",
    "продать": "Сату",
    "отмена": "Бас тарту",
    "подтвердить": "Растау",
    "закрыть": "Жабу",
    "открыть": "Ашу",
    "выбрать": "Таңдау",
    "сохранить": "Сақтау",
    "удалить": "Жою",
    "назад": "Артқа",
    "далее": "Келесі",
    "выход": "Шығу",
    "войти": "Кіру",
    "настройки": "Баптаулар",
    "гафика": "Графика",
    "графика": "Графика",
    "поиск": "Іздеу",
    "помощь": "Көмек",
    "репорт": "Шағым",
    "семья": "Отбасы",
    "дом": "Үй",
    "квартира": "Пәтер",
    "рынок": "Базар",
    "больница": "Аурухана",
    "мэрия": "Әкімдік",
    "оружие": "Қару",
    "патроны": "Оқ-дәрі",
    "здоровье": "Денсаулық",
    "голод": "Аштық",
    "уровень": "Деңгей",
    "опыт": "Тәжірибе",
    "зарплата": "Жалақы",
    "штраф": "Айыппұл",
    "розыск": "Іздеу",
    "квест": "Тапсырма",
    "задание": "Тапсырма",
    "игрок": "Ойыншы",
    "администратор": "Әкімші",
    "недостаточно средств": "Қаражат жеткіліксіз",
    "недостаточно денег": "Қаражат жеткіліксіз",
    "вы уверены?": "Расымен қалайсыз ба?",
    "выберите груз для доставки": "Жеткізу үшін жүкті таңдаңыз",
    "вы попали в больницу после потери сознания": "Есіңізден танып, ауруханаға түстіңіз",
    "получить паспорт в мэрии": "Әкімдікте төлқұжат алу",
}

COMMON_RU_UZ_DICTIONARY: dict[str, str] = {
    "арендовать": "Ijaraga olish",
    "купить": "Sotib olish",
    "продать": "Sotish",
    "отмена": "Bekor qilish",
    "подтвердить": "Tasdiqlash",
    "закрыть": "Yopish",
    "открыть": "Ochish",
    "выбрать": "Tanlash",
    "сохранить": "Saqlash",
    "удалить": "O'chirish",
    "настройки": "Sozlamalar",
    "графика": "Grafika",
    "недостаточно денег": "Mablag' yetarli emas",
    "недостаточно средств": "Mablag' yetarli emas",
    "вы уверены?": "Ishonchingiz komilmi?",
    "выберите груз для доставки": "Yetkazib berish uchun yukni tanlang",
    "вы попали в больницу после потери сознания": "Hushidan ketgandan so'ng shifoxonaga tushdingiz",
}


def _suggest_translation(key: str, src: str, glossary: list[GlossaryEntry], target_lang: str = "kk") -> str:
    s_lower = src.strip().lower()
    dictionary = COMMON_RU_KK_DICTIONARY if target_lang == "kk" else COMMON_RU_UZ_DICTIONARY
    if s_lower in dictionary:
        return dictionary[s_lower]
    for g in glossary:
        if g.ru.lower() == s_lower:
            return g.kk if target_lang == "kk" else g.uz
    out = src
    for ru_w, tr_w in dictionary.items():
        out = re.sub(rf"(?i)\b{re.escape(ru_w)}\b", tr_w, out)
    return out
