"""CLI entrypoint for `locqa` tool."""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
import zipfile
from pathlib import Path

from locqa.analyzer import (
    check_latin_transliteration,
    generate_latin_arb,
    load_arb,
    load_glossary,
    run_qa_checks,
    save_arb,
)
from locqa.fixer import apply_fixes_to_arb
from locqa.llm import calculate_llm_cost_report, refine_findings_with_llm
from locqa.reporter import write_html_report, write_json_report
from locqa.validator import validate_arb_for_flutter


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="locqa",
        description="Qazaq Loc QA: контроль качества казахской и узбекской локализации ARB-файлов (Grand Mobile x Decentrathon 6.0)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # locqa check --source intl_ru.arb --target intl_kk.arb --glossary glossary.csv --out report.json
    check_p = sub.add_parser("check", help="Проверить ARB-файл и сгенерировать JSON + HTML отчеты")
    check_p.add_argument("--source", required=True, help="Путь к исходному ARB-файлу (intl_ru.arb)")
    check_p.add_argument("--target", required=True, help="Путь к целевому ARB-файлу (intl_kk.arb / intl_uz.arb)")
    check_p.add_argument("--glossary", default="glossary.csv", help="Путь к глоссарию (glossary.csv)")
    check_p.add_argument("--out", required=True, help="Путь к выходному JSON-отчету (report.json)")
    check_p.add_argument("--html", default=None, help="Путь к HTML-отчету (по умолчанию рядом с --out)")
    check_p.add_argument("--lang", default=None, help="Код целевого языка (kk, uz, en)")
    check_p.add_argument("--use-llm", action="store_true", help="Уточнить suggestion через LLM API (при наличии OPENAI_API_KEY / LLM_API_KEY)")
    check_p.add_argument("--fail-on-high", action="store_true", help="Вернуть ненулевой код выхода при наличии high-ошибок (для CI)")

    # locqa fix --source intl_ru.arb --target intl_kk.arb --glossary glossary.csv --out intl_kk_fixed.arb
    fix_p = sub.add_parser("fix", help="Создать исправленный ARB-файл с отметками reviewed_by_human")
    fix_p.add_argument("--source", required=True, help="Путь к исходному ARB-файлу (intl_ru.arb)")
    fix_p.add_argument("--target", required=True, help="Путь к целевому ARB-файлу (intl_kk.arb)")
    fix_p.add_argument("--glossary", default="glossary.csv", help="Путь к глоссарию (glossary.csv)")
    fix_p.add_argument("--out", required=True, help="Путь к исправленному ARB-файлу (intl_kk_fixed.arb)")
    fix_p.add_argument("--use-llm", action="store_true", help="Уточнить suggestion через LLM API перед записью")

    # locqa translit --source intl_ru.arb --target intl_kk.arb --out intl_kk_latn.json
    tr_p = sub.add_parser("translit", help="Бонус: транслитерация казахского ARB в официальную латиницу с проверкой длины")
    tr_p.add_argument("--source", required=True, help="Путь к исходному ARB-файлу (intl_ru.arb)")
    tr_p.add_argument("--target", required=True, help="Путь к казахскому ARB-файлу (intl_kk.arb)")
    tr_p.add_argument("--out", required=True, help="Путь к выходному JSON-отчету латиницы")
    tr_p.add_argument("--arb-out", default=None, help="Опциональный путь для сохранения ARB-файла на латинице (intl_kk_latin.arb)")

    # locqa validate --source intl_ru.arb --fixed intl_kk_fixed.arb
    val_p = sub.add_parser("validate", help="Проверить валидность ARB для flutter gen-l10n и флагов reviewed_by_human")
    val_p.add_argument("--source", required=True, help="Путь к исходному ARB-файлу (intl_ru.arb)")
    val_p.add_argument("--fixed", required=True, help="Путь к исправленному ARB-файлу (intl_kk_fixed.arb)")
    val_p.add_argument("--original", default=None, help="Путь к исходному целевому ARB-файлу (intl_kk.arb)")

    # locqa pipeline --input hack-4e892c51-sharkmove.zip --out-dir ./output
    pipe_p = sub.add_parser("pipeline", help="Пакетный прогон всех задач и бонусов по .zip архиву или папке с ARB-файлами")
    pipe_p.add_argument("--input", required=True, help="Путь к .zip архиву (например hack-4e892c51-sharkmove.zip) или папке с intl_*.arb")
    pipe_p.add_argument("--glossary", default="glossary.csv", help="Путь к глоссарию (glossary.csv)")
    pipe_p.add_argument("--out-dir", default=".", help="Директория для сохранения report.json, report.html, intl_kk_fixed.arb и бонусов")

    return parser


def infer_lang(target_path: str, arb_data: dict) -> str:
    locale = str(arb_data.get("@@locale", "")).lower()
    if locale in ("kk", "uz", "en", "ru"):
        return locale
    name = Path(target_path).name.lower()
    if "uz" in name:
        return "uz"
    if "en" in name:
        return "en"
    return "kk"


def _run_full_pipeline(input_path: Path, glossary_path: str, out_dir: Path) -> int:
    out_dir.mkdir(parents=True, exist_ok=True)
    glossary = load_glossary(glossary_path)

    with tempfile.TemporaryDirectory() as tmp:
        search_root = input_path
        if input_path.is_file() and input_path.suffix.lower() == ".zip":
            with zipfile.ZipFile(input_path, "r") as zf:
                zf.extractall(tmp)
            search_root = Path(tmp)

        arb_files = {p.name: p for p in search_root.rglob("*.arb")}
        if "intl_ru.arb" not in arb_files or "intl_kk.arb" not in arb_files:
            print(f"[locqa] Ошибка: в '{input_path}' не найдены обязательные файлы intl_ru.arb и intl_kk.arb", file=sys.stderr)
            return 1

        src = load_arb(arb_files["intl_ru.arb"])
        tgt_kk = load_arb(arb_files["intl_kk.arb"])
        total_keys = sum(1 for k in src if not k.startswith("@"))

        # 1. Kazakh check & report
        findings_kk = run_qa_checks(src, tgt_kk, glossary=glossary, target_lang="kk")
        report_json = out_dir / "report.json"
        report_html = out_dir / "report.html"
        write_json_report(findings_kk, report_json)
        write_html_report(findings_kk, report_html, "intl_ru.arb", "intl_kk.arb", total_keys=total_keys)

        # 2. Kazakh fix & flutter gen-l10n validation
        fixed_kk = apply_fixes_to_arb(src, tgt_kk, findings_kk, mark_reviewed=True)
        fixed_kk_path = out_dir / "intl_kk_fixed.arb"
        save_arb(fixed_kk, fixed_kk_path)
        val_res = validate_arb_for_flutter(src, fixed_kk, tgt_kk)

        # 3. Bonus: Kazakh Latin transliteration
        latin_rows = check_latin_transliteration(src, fixed_kk)
        latin_report_path = out_dir / "intl_kk_latin_report.json"
        with open(latin_report_path, "w", encoding="utf-8") as f:
            json.dump(latin_rows, f, ensure_ascii=False, indent=2)
            f.write("\n")
        save_arb(generate_latin_arb(fixed_kk), out_dir / "intl_kk_latin.arb")

        # 4. Bonus: Uzbek check & fix if intl_uz.arb is present
        uz_count = 0
        if "intl_uz.arb" in arb_files:
            tgt_uz = load_arb(arb_files["intl_uz.arb"])
            findings_uz = run_qa_checks(src, tgt_uz, glossary=glossary, target_lang="uz")
            uz_count = len(findings_uz)
            write_json_report(findings_uz, out_dir / "report_uz.json")
            write_html_report(findings_uz, out_dir / "report_uz.html", "intl_ru.arb", "intl_uz.arb", total_keys=total_keys)
            fixed_uz = apply_fixes_to_arb(src, tgt_uz, findings_uz, mark_reviewed=True)
            save_arb(fixed_uz, out_dir / "intl_uz_fixed.arb")

        # 5. LLM Cost & Metrics summary
        cost_est = calculate_llm_cost_report(src, findings_kk)
        summary = {
            "total_source_keys": total_keys,
            "kazakh_findings_count": len(findings_kk),
            "uzbek_findings_count": uz_count,
            "flutter_gen_l10n_valid": val_res.valid,
            "modified_keys_reviewed_by_human": val_res.reviewed_by_human_count,
            "llm_cost_estimate": cost_est.to_dict(),
        }
        with open(out_dir / "metrics_summary.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
            f.write("\n")

        print(
            f"[locqa pipeline] Готово!\n"
            f"  - Ключей проверено: {total_keys}\n"
            f"  - Находок KK: {len(findings_kk)} (отчеты: {report_json}, {report_html})\n"
            f"  - Исправленный ARB: {fixed_kk_path} (flutter gen-l10n valid: {val_res.valid})\n"
            f"  - Находок UZ (бонус): {uz_count}\n"
            f"  - Оценка стоимости гибридного LLM: ${cost_est.estimated_cost_usd:.4f} (экономия {cost_est.savings_percent}%)"
        )
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "check":
        src = load_arb(args.source)
        tgt = load_arb(args.target)
        glossary = load_glossary(args.glossary)
        lang = args.lang or infer_lang(args.target, tgt)

        findings = run_qa_checks(src, tgt, glossary=glossary, target_lang=lang)
        if args.use_llm:
            findings, _ = refine_findings_with_llm(findings, glossary, target_lang=lang)

        write_json_report(findings, args.out)

        html_path = args.html
        if not html_path:
            out_p = Path(args.out)
            html_path = str(out_p.with_suffix(".html"))

        total_keys = sum(1 for k in src if not k.startswith("@"))
        write_html_report(
            findings,
            html_path,
            source_name=Path(args.source).name,
            target_name=Path(args.target).name,
            total_keys=total_keys,
        )

        high_cnt = sum(1 for f in findings if f.severity == "high")
        cost_est = calculate_llm_cost_report(src, findings)
        print(
            f"[locqa] Проверено ключей: {total_keys} | Найдено ошибок: {len(findings)} "
            f"(high: {high_cnt}) | Оценка стоимости LLM: ${cost_est.estimated_cost_usd:.5f} | "
            f"Отчеты: {args.out}, {html_path}"
        )
        if args.fail_on_high and high_cnt > 0:
            return 1
        return 0

    if args.command == "fix":
        src = load_arb(args.source)
        tgt = load_arb(args.target)
        glossary = load_glossary(args.glossary)
        lang = infer_lang(args.target, tgt)
        findings = run_qa_checks(src, tgt, glossary=glossary, target_lang=lang)
        if args.use_llm:
            findings, _ = refine_findings_with_llm(findings, glossary, target_lang=lang)
        fixed_arb = apply_fixes_to_arb(src, tgt, findings, mark_reviewed=True)
        save_arb(fixed_arb, args.out)
        val = validate_arb_for_flutter(src, fixed_arb, tgt)
        print(
            f"[locqa] Исправлено строк: {val.modified_keys} (reviewed_by_human: {val.reviewed_by_human_count}) "
            f"| flutter gen-l10n valid: {val.valid} | Сохранено в: {args.out}"
        )
        return 0

    if args.command == "translit":
        src = load_arb(args.source)
        tgt = load_arb(args.target)
        rows = check_latin_transliteration(src, tgt)
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False, indent=2)
            f.write("\n")
        if args.arb_out:
            save_arb(generate_latin_arb(tgt), args.arb_out)
        warnings = sum(1 for r in rows if r["length_warning"])
        print(f"[locqa] Транслитерировано ключей: {len(rows)} | Предупреждений о длине: {warnings} | Сохранено: {args.out}")
        return 0

    if args.command == "validate":
        src = load_arb(args.source)
        fixed = load_arb(args.fixed)
        orig = load_arb(args.original) if args.original else None
        res = validate_arb_for_flutter(src, fixed, orig)
        print(json.dumps(res.to_dict(), ensure_ascii=False, indent=2))
        return 0 if res.valid else 1

    if args.command == "pipeline":
        return _run_full_pipeline(Path(args.input), args.glossary, Path(args.out_dir))

    return 0


if __name__ == "__main__":
    sys.exit(main())
