"""Apply verified fixes to Flutter ARB files with reviewed_by_human metadata."""

from __future__ import annotations

import copy
from typing import Any

from locqa.analyzer import Finding


def apply_fixes_to_arb(
    source_arb: dict[str, Any],
    target_arb: dict[str, Any],
    findings: list[Finding],
    mark_reviewed: bool = True,
) -> dict[str, Any]:
    """Return a fixed copy of target_arb where each finding with a suggestion is applied and marked."""
    fixed: dict[str, Any] = copy.deepcopy(target_arb)
    findings_by_key: dict[str, Finding] = {}
    for f in findings:
        # Prioritize high severity or first finding per key
        if f.key not in findings_by_key or f.severity == "high":
            findings_by_key[f.key] = f

    # Ensure ordering follows source_arb keys where possible
    result: dict[str, Any] = {}
    if "@@locale" in fixed:
        result["@@locale"] = fixed["@@locale"]
    else:
        result["@@locale"] = "kk"

    for key, src_val in source_arb.items():
        if key == "@@locale":
            continue
        if key.startswith("@"):
            continue

        finding = findings_by_key.get(key)
        orig_target = fixed.get(key)
        meta_key = f"@{key}"
        existing_meta = copy.deepcopy(fixed.get(meta_key)) if isinstance(fixed.get(meta_key), dict) else {}

        if finding and finding.suggestion and finding.suggestion != orig_target:
            result[key] = finding.suggestion
            existing_meta["reviewed_by_human"] = bool(mark_reviewed and finding.reviewed_by_human)
            existing_meta["fixed_issue_type"] = finding.issue_type
            result[meta_key] = existing_meta
        else:
            if key in fixed:
                result[key] = orig_target
            else:
                result[key] = src_val
            if meta_key in fixed:
                result[meta_key] = existing_meta

    return result
