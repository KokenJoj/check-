"""Hybrid LLM integration and token/cost calculator for Qazaq Loc QA."""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from typing import Any

from locqa.analyzer import Finding, GlossaryEntry

# Pricing per 1M tokens in USD (standard public API rates)
MODEL_PRICING_PER_1M: dict[str, tuple[float, float]] = {
    "gpt-4o-mini": (0.15, 0.60),
    "gemini-2.5-flash": (0.15, 0.60),
    "gpt-4o": (2.50, 10.00),
    "claude-3-5-sonnet": (3.00, 15.00),
}


@dataclass
class LLMCostEstimate:
    model: str
    total_arb_keys: int
    suspect_keys_sent_to_llm: int
    estimated_input_tokens: int
    estimated_output_tokens: int
    estimated_cost_usd: float
    full_retranslation_cost_usd: float
    savings_percent: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def estimate_tokens(text: str) -> int:
    """Approximate BPE token count for Cyrillic/Kazakh/JSON strings (~2.8 chars per token)."""
    if not text:
        return 0
    return max(1, int(len(text) / 2.8) + 4)


def calculate_llm_cost_report(
    source_arb: dict[str, Any],
    findings: list[Finding],
    model: str = "gpt-4o-mini",
) -> LLMCostEstimate:
    """Calculate token usage and USD cost for hybrid QA vs naive full-file LLM translation."""
    in_price, out_price = MODEL_PRICING_PER_1M.get(model, (0.15, 0.60))

    real_keys = [k for k, v in source_arb.items() if not k.startswith("@") and isinstance(v, str)]
    total_keys = len(real_keys)

    # Full naive retranslation token estimate (all keys + system prompt overhead)
    full_in_tokens = sum(estimate_tokens(str(source_arb[k])) + 45 for k in real_keys)
    full_out_tokens = sum(estimate_tokens(str(source_arb[k])) + 25 for k in real_keys)
    full_cost = (full_in_tokens / 1_000_000) * in_price + (full_out_tokens / 1_000_000) * out_price

    # Hybrid approach: only send flagged/suspect keys to LLM for verification & suggestion refinement
    unique_flagged_keys = {f.key for f in findings}
    suspect_count = len(unique_flagged_keys)

    hybrid_in_tokens = 350 if suspect_count > 0 else 0  # system prompt + glossary context
    hybrid_out_tokens = 0
    for f in findings:
        hybrid_in_tokens += estimate_tokens(f.source) + estimate_tokens(f.target) + 35
        hybrid_out_tokens += estimate_tokens(f.suggestion) + 30

    hybrid_cost = (hybrid_in_tokens / 1_000_000) * in_price + (hybrid_out_tokens / 1_000_000) * out_price
    savings = 0.0
    if full_cost > 0:
        savings = round(max(0.0, (1.0 - (hybrid_cost / full_cost)) * 100.0), 1)

    return LLMCostEstimate(
        model=model,
        total_arb_keys=total_keys,
        suspect_keys_sent_to_llm=suspect_count,
        estimated_input_tokens=hybrid_in_tokens,
        estimated_output_tokens=hybrid_out_tokens,
        estimated_cost_usd=round(hybrid_cost, 6),
        full_retranslation_cost_usd=round(full_cost, 6),
        savings_percent=savings,
    )


def refine_findings_with_llm(
    findings: list[Finding],
    glossary: list[GlossaryEntry],
    target_lang: str = "kk",
    api_key: str | None = None,
    base_url: str | None = None,
    model: str | None = None,
) -> tuple[list[Finding], bool]:
    """
    Optionally refine suggestions using an OpenAI-compatible LLM endpoint.
    Falls back cleanly to deterministic suggestions if no API key is configured.
    """
    key = api_key or os.environ.get("LLM_API_KEY") or os.environ.get("OPENAI_API_KEY")
    if not key or not findings:
        return findings, False

    url = (base_url or os.environ.get("LLM_BASE_URL") or "https://api.openai.com/v1").rstrip("/") + "/chat/completions"
    mdl = model or os.environ.get("LLM_MODEL") or "gpt-4o-mini"

    glossary_str = "\n".join(f"- {g.ru} -> {g.kk if target_lang == 'kk' else g.uz} ({g.comment})" for g in glossary[:30])

    # Batch up to 25 findings to keep latency low
    batch = findings[:25]
    items_payload = [
        {
            "key": f.key,
            "issue_type": f.issue_type,
            "source_ru": f.source,
            "target_current": f.target,
            "rule_suggestion": f.suggestion,
        }
        for f in batch
    ]

    system_prompt = (
        "Ты — ведущий редактор казахской и узбекской локализации мобильной игры Grand Mobile. "
        "Твоя задача — проверить и улучшить исправления (suggestion) для найденных ошибок в ARB-файле.\n"
        "Правила:\n"
        "1. Строго сохраняй все плейсхолдеры вида {name}, {count} и ICU синтаксис.\n"
        "2. Не ставь падежные аффиксы (-ға/-ге/-дан) вплотную после плейсхолдера {name}.\n"
        "3. Для коротких кнопок (_btn, _button, _tab) давай максимально краткий перевод (1-2 слова).\n"
        f"Глоссарий:\n{glossary_str}\n"
        "Верни JSON объект вида {\"suggestions\": {\"key\": \"исправленный перевод\"}}."
    )

    req_body = json.dumps(
        {
            "model": mdl,
            "temperature": 0.1,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": json.dumps(items_payload, ensure_ascii=False)},
            ],
        }
    ).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=req_body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            resp_data = json.loads(resp.read().decode("utf-8"))
            content = resp_data["choices"][0]["message"]["content"]
            parsed = json.loads(content)
            sug_map = parsed.get("suggestions", {})
            if isinstance(sug_map, dict):
                for f in findings:
                    if f.key in sug_map and isinstance(sug_map[f.key], str) and sug_map[f.key].strip():
                        f.suggestion = sug_map[f.key].strip()
                return findings, True
    except (urllib.error.URLError, KeyError, json.JSONDecodeError, TimeoutError):
        pass

    return findings, False
