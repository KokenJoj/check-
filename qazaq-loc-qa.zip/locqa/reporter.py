"""Generate standalone HTML and JSON reports for Qazaq Loc QA."""

from __future__ import annotations

import html
import json
from collections import Counter
from pathlib import Path
from typing import Any

from locqa.analyzer import Finding


def write_json_report(findings: list[Finding], out_path: str | Path) -> None:
    payload = [f.to_dict() for f in findings]
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")


def generate_html_report(
    findings: list[Finding],
    source_name: str = "intl_ru.arb",
    target_name: str = "intl_kk.arb",
    total_keys: int = 0,
) -> str:
    by_type = Counter(f.issue_type for f in findings)
    by_sev = Counter(f.severity for f in findings)
    reviewed_count = sum(1 for f in findings if f.reviewed_by_human)

    type_badges_html = "".join(
        f'<span class="chip"><strong>{html.escape(k)}</strong>: {v}</span>'
        for k, v in sorted(by_type.items(), key=lambda x: -x[1])
    )

    rows_html = []
    for f in findings:
        sev_class = f"sev-{html.escape(f.severity)}"
        rev_badge = (
            '<span class="rev-yes">Проверено носителем</span>'
            if f.reviewed_by_human
            else '<span class="rev-no">Черновик</span>'
        )
        rows_html.append(
            f"""
            <tr data-type="{html.escape(f.issue_type)}" data-sev="{html.escape(f.severity)}">
              <td class="mono">{html.escape(f.key)}</td>
              <td><span class="type-tag">{html.escape(f.issue_type)}</span></td>
              <td><span class="sev-badge {sev_class}">{html.escape(f.severity)}</span></td>
              <td>{html.escape(f.source)}</td>
              <td class="target-cell">{html.escape(f.target)}</td>
              <td class="sug-cell">{html.escape(f.suggestion)}</td>
              <td class="ev-cell">{html.escape(f.evidence)}</td>
              <td class="mono">{f.confidence:.2f}</td>
              <td>{rev_badge}</td>
            </tr>
            """
        )

    return f"""<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Qazaq Loc QA Report — {html.escape(target_name)}</title>
  <style>
    :root {{
      --bg: #0f172a;
      --card: #1e293b;
      --border: #334155;
      --text: #f8fafc;
      --muted: #94a3b8;
      --accent: #38bdf8;
      --high: #ef4444;
      --medium: #f59e0b;
      --low: #10b981;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      padding: 24px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: var(--bg);
      color: var(--text);
    }}
    .header {{
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 16px;
      margin-bottom: 24px;
      padding: 20px;
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 12px;
    }}
    h1 {{ margin: 0 0 8px 0; font-size: 22px; }}
    .sub {{ color: var(--muted); font-size: 14px; }}
    .stats {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 12px;
      margin-bottom: 20px;
    }}
    .stat-card {{
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 14px 16px;
    }}
    .stat-val {{ font-size: 26px; font-weight: 700; color: var(--accent); }}
    .stat-lbl {{ font-size: 12px; color: var(--muted); margin-top: 4px; }}
    .chips {{ display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 20px; }}
    .chip {{
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 999px;
      padding: 6px 12px;
      font-size: 13px;
    }}
    .table-wrap {{
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 12px;
      overflow-x: auto;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
    }}
    th, td {{
      padding: 10px 12px;
      text-align: left;
      border-bottom: 1px solid var(--border);
      vertical-align: top;
    }}
    th {{
      background: #0b1120;
      color: var(--muted);
      font-weight: 600;
      position: sticky;
      top: 0;
    }}
    .mono {{ font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 12px; }}
    .type-tag {{
      background: rgba(56, 189, 248, 0.14);
      color: var(--accent);
      padding: 3px 8px;
      border-radius: 6px;
      font-family: ui-monospace, monospace;
      font-size: 12px;
      white-space: nowrap;
    }}
    .sev-badge {{
      padding: 2px 8px;
      border-radius: 6px;
      font-weight: 600;
      font-size: 11px;
      text-transform: uppercase;
    }}
    .sev-high {{ background: rgba(239, 68, 68, 0.2); color: #fca5a5; }}
    .sev-medium {{ background: rgba(245, 158, 11, 0.2); color: #fcd34d; }}
    .sev-low {{ background: rgba(16, 185, 129, 0.2); color: #6ee7b7; }}
    .target-cell {{ color: #fca5a5; }}
    .sug-cell {{ color: #86efac; font-weight: 500; }}
    .ev-cell {{ color: #cbd5e1; max-width: 340px; }}
    .rev-yes {{ color: #6ee7b7; font-size: 12px; white-space: nowrap; }}
    .rev-no {{ color: #fcd34d; font-size: 12px; white-space: nowrap; }}
  </style>
</head>
<body>
  <div class="header">
    <div>
      <h1>Qazaq Loc QA — Отчет проверки локализации Grand Mobile</h1>
      <div class="sub">Исходник: <strong>{html.escape(source_name)}</strong> &rarr; Цель: <strong>{html.escape(target_name)}</strong> (Всего ключей: {total_keys})</div>
    </div>
    <div class="sub">Decentrathon 6.0 &times; Grand Mobile (Case 02)</div>
  </div>

  <div class="stats">
    <div class="stat-card">
      <div class="stat-val">{len(findings)}</div>
      <div class="stat-lbl">Всего находок</div>
    </div>
    <div class="stat-card">
      <div class="stat-val" style="color: #fca5a5;">{by_sev.get("high", 0)}</div>
      <div class="stat-lbl">High Severity</div>
    </div>
    <div class="stat-card">
      <div class="stat-val" style="color: #fcd34d;">{by_sev.get("medium", 0)}</div>
      <div class="stat-lbl">Medium Severity</div>
    </div>
    <div class="stat-card">
      <div class="stat-val" style="color: #6ee7b7;">{reviewed_count}</div>
      <div class="stat-lbl">Проверено носителем (reviewed_by_human)</div>
    </div>
  </div>

  <div class="chips">{type_badges_html}</div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Key</th>
          <th>Issue Type</th>
          <th>Severity</th>
          <th>Source (RU)</th>
          <th>Target (Current)</th>
          <th>Suggestion (Fixed)</th>
          <th>Evidence</th>
          <th>Conf.</th>
          <th>Review</th>
        </tr>
      </thead>
      <tbody>
        {"".join(rows_html)}
      </tbody>
    </table>
  </div>
</body>
</html>
"""


def write_html_report(
    findings: list[Finding],
    out_path: str | Path,
    source_name: str = "intl_ru.arb",
    target_name: str = "intl_kk.arb",
    total_keys: int = 0,
) -> None:
    html_str = generate_html_report(
        findings,
        source_name=source_name,
        target_name=target_name,
        total_keys=total_keys,
    )
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html_str)
