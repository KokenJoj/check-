"""Transliteration from Kazakh Cyrillic to Official Kazakh Latin Alphabet."""

from __future__ import annotations

# Official Kazakh Latin Alphabet mapping (2021 revised standard with diacritics)
CYR_TO_LAT_MAP: dict[str, str] = {
    "А": "A", "а": "a",
    "Ә": "Ä", "ә": "ä",
    "Б": "B", "б": "b",
    "В": "V", "в": "v",
    "Г": "G", "г": "g",
    "Ғ": "Ğ", "ғ": "ğ",
    "Д": "D", "д": "d",
    "Е": "E", "е": "e",
    "Ё": "Yo", "ё": "yo",
    "Ж": "J", "ж": "j",
    "З": "Z", "з": "z",
    "И": "İ", "и": "i",
    "Й": "İ", "й": "i",
    "К": "K", "к": "k",
    "Қ": "Q", "қ": "q",
    "Л": "L", "л": "l",
    "М": "M", "м": "m",
    "Н": "N", "н": "n",
    "Ң": "Ñ", "ң": "ñ",
    "О": "O", "о": "o",
    "Ө": "Ö", "ө": "ö",
    "П": "P", "п": "p",
    "Р": "R", "р": "r",
    "С": "S", "с": "s",
    "Т": "T", "т": "t",
    "У": "U", "у": "u",
    "Ұ": "Ū", "ұ": "ū",
    "Ү": "Ü", "ү": "ü",
    "Ф": "F", "ф": "f",
    "Х": "H", "х": "h",
    "Һ": "H", "һ": "h",
    "Ц": "Ts", "ц": "ts",
    "Ч": "Ch", "ч": "ch",
    "Ш": "Ş", "ш": "ş",
    "Щ": "Şş", "щ": "şş",
    "Ъ": "", "ъ": "",
    "Ы": "Y", "ы": "y",
    "І": "İ", "і": "i",
    "Ь": "", "ь": "",
    "Э": "E", "э": "e",
    "Ю": "Yu", "ю": "yu",
    "Я": "Ya", "я": "ya",
}


def transliterate_kk_to_latin(text: str) -> str:
    """Transliterate Kazakh Cyrillic text to Latin while preserving {placeholders}."""
    if not text:
        return ""
    result: list[str] = []
    in_brace = 0
    for ch in text:
        if ch == "{":
            in_brace += 1
            result.append(ch)
        elif ch == "}":
            in_brace = max(0, in_brace - 1)
            result.append(ch)
        elif in_brace > 0:
            result.append(ch)
        else:
            result.append(CYR_TO_LAT_MAP.get(ch, ch))
    return "".join(result)
