"""Validator ensuring ARB files compile cleanly with `flutter gen-l10n` and meet Case 02 constraints."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from typing import Any

from locqa.analyzer import ICU_HEADER_RE, PLACEHOLDER_RE, check_plural_icu, extract_placeholders

DART_IDENT_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


@dataclass
class ValidationResult:
    valid: bool
    locale: str
    total_keys: int
    modified_keys: int
    reviewed_by_human_count: int
    unreviewed_modified_keys: list[str]
    errors: list[str]
    warnings: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def validate_arb_for_flutter(
    source_arb: dict[str, Any],
    fixed_arb: dict[str, Any],
    original_target_arb: dict[str, Any] | None = None,
) -> ValidationResult:
    """
    Validate that `fixed_arb` is 100% compatible with `flutter gen-l10n` and satisfies
    Grand Mobile x Decentrathon 6.0 requirements (all changed strings marked reviewed_by_human).
    """
    errors: list[str] = []
    warnings: list[str] = []

    locale = str(fixed_arb.get("@@locale", ""))
    if not locale:
        errors.append("Отсутствует обязательный ключ '@@locale' для flutter gen-l10n")

    total_keys = 0
    modified_keys = 0
    reviewed_count = 0
    unreviewed_keys: list[str] = []

    for key, src_val in source_arb.items():
        if key == "@@locale" or key.startswith("@"):
            continue
        if not isinstance(src_val, str):
            continue

        total_keys += 1
        if not DART_IDENT_RE.match(key):
            errors.append(f"Ключ '{key}' не является валидным Dart-идентификатором для flutter gen-l10n")

        if key not in fixed_arb:
            errors.append(f"Ключ '{key}' отсутствует в целевом ARB-файле")
            continue

        tgt_val = fixed_arb[key]
        if not isinstance(tgt_val, str) or not tgt_val.strip():
            errors.append(f"Ключ '{key}' имеет пустое или нестроковое значение")
            continue

        # Check balanced braces and ICU syntax
        has_icu_err, icu_ev, _ = check_plural_icu(src_val, tgt_val)
        if has_icu_err:
            errors.append(f"Ошибка ICU синтаксиса в ключе '{key}': {icu_ev}")

        if tgt_val.count("{") != tgt_val.count("}"):
            errors.append(f"Несбалансированные фигурные скобки в ключе '{key}': {tgt_val}")

        # Check placeholders match source
        src_ph = extract_placeholders(src_val)
        tgt_ph = extract_placeholders(tgt_val)
        if src_ph != tgt_ph:
            errors.append(f"Несовпадение плейсхолдеров в ключе '{key}': исходник {src_ph} != перевод {tgt_ph}")

        for ph in tgt_ph:
            if not DART_IDENT_RE.match(ph):
                errors.append(f"Плейсхолдер '{{{ph}}}' в ключе '{key}' невалиден для Dart/Flutter")

        # Check reviewed_by_human flag on modified strings
        if original_target_arb is not None:
            orig_val = original_target_arb.get(key)
            if orig_val != tgt_val:
                modified_keys += 1
                meta = fixed_arb.get(f"@{key}")
                is_rev = isinstance(meta, dict) and bool(meta.get("reviewed_by_human"))
                if is_rev:
                    reviewed_count += 1
                else:
                    unreviewed_keys.append(key)
                    warnings.append(f"Измененная строка '{key}' не имеет флага @'{key}'.reviewed_by_human = true")

    return ValidationResult(
        valid=len(errors) == 0,
        locale=locale,
        total_keys=total_keys,
        modified_keys=modified_keys,
        reviewed_by_human_count=reviewed_count,
        unreviewed_modified_keys=unreviewed_keys,
        errors=errors,
        warnings=warnings,
    )
