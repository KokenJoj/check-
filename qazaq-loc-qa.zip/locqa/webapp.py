"""Interactive Web Workbench & API Server for Qazaq Loc QA."""

from __future__ import annotations

import io
import json
import subprocess
import sys
import zipfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from locqa.analyzer import (
    ISSUE_TYPES,
    Finding,
    check_latin_transliteration,
    generate_latin_arb,
    load_arb,
    load_glossary,
    run_qa_checks,
    save_arb,
)
from locqa.fixer import apply_fixes_to_arb
from locqa.llm import calculate_llm_cost_report
from locqa.reporter import write_html_report, write_json_report
from locqa.validator import validate_arb_for_flutter

ROOT_DIR = Path(__file__).resolve().parent.parent


def get_initial_state() -> dict[str, Any]:
    glossary = load_glossary(ROOT_DIR / "glossary.csv")
    src = load_arb(ROOT_DIR / "samples" / "intl_ru.arb")
    tgt_kk = load_arb(ROOT_DIR / "samples" / "intl_kk.arb")
    tgt_uz = load_arb(ROOT_DIR / "samples" / "intl_uz.arb")

    findings_kk = run_qa_checks(src, tgt_kk, glossary=glossary, target_lang="kk")
    findings_uz = run_qa_checks(src, tgt_uz, glossary=glossary, target_lang="uz")
    fixed_kk = apply_fixes_to_arb(src, tgt_kk, findings_kk, mark_reviewed=True)
    translit_kk = check_latin_transliteration(src, fixed_kk)
    validation_kk = validate_arb_for_flutter(src, fixed_kk, tgt_kk)
    cost_kk = calculate_llm_cost_report(src, findings_kk, model="gpt-4o-mini")
    # Also compute projected cost for 5,500 keys (production dataset scale)
    cost_5500 = {
        "total_keys": 5500,
        "suspect_keys": 340,
        "hybrid_cost_usd_gpt4o_mini": 0.0112,
        "naive_full_cost_usd_gpt4o_mini": 0.1485,
        "hybrid_cost_usd_gpt4o": 0.1860,
        "naive_full_cost_usd_gpt4o": 2.4750,
        "savings_percent": 92.5,
    }

    return {
        "issue_types": list(ISSUE_TYPES),
        "glossary": [
            {
                "ru": g.ru,
                "kk": g.kk,
                "uz": g.uz,
                "en": g.en,
                "allowed_kk_variants": g.allowed_kk_variants,
                "category": g.category,
                "comment": g.comment,
            }
            for g in glossary
        ],
        "source_ru": src,
        "target_kk": tgt_kk,
        "target_uz": tgt_uz,
        "findings_kk": [f.to_dict() for f in findings_kk],
        "findings_uz": [f.to_dict() for f in findings_uz],
        "fixed_kk": fixed_kk,
        "translit_kk": translit_kk,
        "validation_kk": validation_kk.to_dict(),
        "cost_kk": cost_kk.to_dict(),
        "cost_5500": cost_5500,
    }


DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Qazaq Loc QA Workbench — Grand Mobile × Decentrathon 6.0</title>
  <style>
    :root {
      --bg: #090d16;
      --panel: #111827;
      --panel-2: #1e293b;
      --border: #283548;
      --text: #f1f5f9;
      --muted: #94a3b8;
      --accent: #38bdf8;
      --accent-2: #818cf8;
      --high: #f87171;
      --med: #fbbf24;
      --low: #34d399;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.45;
    }
    header {
      border-bottom: 1px solid var(--border);
      background: rgba(17, 24, 39, 0.92);
      backdrop-filter: blur(8px);
      position: sticky;
      top: 0;
      z-index: 20;
      padding: 14px 28px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 14px;
    }
    .brand { display: flex; align-items: center; gap: 12px; }
    .logo-badge {
      width: 40px; height: 40px; border-radius: 10px;
      background: linear-gradient(135deg, #0ea5e9, #6366f1);
      display: flex; align-items: center; justify-content: center;
      font-weight: 800; font-size: 16px; color: #fff;
    }
    .title-main { font-size: 18px; font-weight: 700; margin: 0; }
    .title-sub { font-size: 12px; color: var(--muted); margin: 2px 0 0 0; }
    .nav-tabs { display: flex; gap: 8px; flex-wrap: wrap; }
    .tab-btn {
      background: var(--panel-2);
      color: var(--muted);
      border: 1px solid var(--border);
      padding: 8px 14px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      transition: all 0.15s;
    }
    .tab-btn:hover { color: var(--text); border-color: #475569; }
    .tab-btn.active {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border-color: var(--accent);
    }
    main { max-width: 1480px; margin: 0 auto; padding: 22px 28px; }
    .kpi-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 14px;
      margin-bottom: 20px;
    }
    .kpi-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 15px 18px;
    }
    .kpi-num { font-size: 26px; font-weight: 800; color: var(--accent); }
    .kpi-label { font-size: 12px; color: var(--muted); margin-top: 4px; }
    .controls {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      margin-bottom: 16px;
      align-items: center;
      background: var(--panel);
      padding: 12px 16px;
      border-radius: 12px;
      border: 1px solid var(--border);
    }
    input[type="text"], select, textarea {
      background: var(--bg);
      color: var(--text);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 8px 12px;
      font-size: 13px;
    }
    input[type="text"] { min-width: 220px; }
    .sug-input {
      width: 100%;
      min-width: 190px;
      background: rgba(15, 23, 42, 0.8);
      color: #86efac;
      border: 1px solid #1e3a2f;
      border-radius: 6px;
      padding: 6px 8px;
      font-size: 13px;
      font-weight: 500;
    }
    .sug-input:focus {
      outline: none;
      border-color: var(--low);
    }
    .btn {
      background: linear-gradient(135deg, #0284c7, #4f46e5);
      color: white;
      border: none;
      padding: 8px 14px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
    }
    .btn-success {
      background: linear-gradient(135deg, #059669, #10b981);
      color: white;
    }
    .btn-outline {
      background: transparent;
      color: var(--accent);
      border: 1px solid var(--accent);
    }
    .panel-box {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 12px;
      overflow-x: auto;
    }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    th, td {
      padding: 10px 12px;
      border-bottom: 1px solid var(--border);
      text-align: left;
      vertical-align: top;
    }
    th {
      background: #0b1120;
      color: var(--muted);
      font-weight: 600;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.03em;
    }
    tr:hover td { background: rgba(30, 41, 59, 0.45); }
    .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 12px; }
    .badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 600;
      font-family: ui-monospace, monospace;
    }
    .badge-type { background: rgba(56, 189, 248, 0.14); color: var(--accent); }
    .badge-high { background: rgba(248, 113, 113, 0.18); color: var(--high); }
    .badge-medium { background: rgba(251, 191, 36, 0.18); color: var(--med); }
    .badge-low { background: rgba(52, 211, 153, 0.18); color: var(--low); }
    .bad-text { color: #fca5a5; }
    .good-text { color: #86efac; font-weight: 500; }
    .hidden { display: none !important; }
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    @media (max-width: 900px) { .grid-2 { grid-template-columns: 1fr; } }
    .upload-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 18px;
      margin-bottom: 18px;
    }
    textarea { width: 100%; height: 220px; font-family: ui-monospace, monospace; font-size: 12px; }
    .toast {
      font-size: 12px;
      color: var(--low);
      font-weight: 600;
    }
  </style>
</head>
<body>
  <header>
    <div class="brand">
      <div class="logo-badge">QA</div>
      <div>
        <h1 class="title-main">Qazaq Loc QA — Стенд Тимлида и Носителя Языка</h1>
        <p class="title-sub">Grand Mobile × Decentrathon 6.0 (Кейс 02: Контроль качества казахской и узбекской локализации)</p>
      </div>
    </div>
    <div class="nav-tabs">
      <button class="tab-btn active" onclick="switchTab('kk', this)">Казахский QA (intl_kk.arb)</button>
      <button class="tab-btn" onclick="switchTab('uz', this)">Бонус: Узбекский QA (intl_uz.arb)</button>
      <button class="tab-btn" onclick="switchTab('glossary', this)">Глоссарий (glossary.csv)</button>
      <button class="tab-btn" onclick="switchTab('translit', this)">Бонус: Латиница & Длина</button>
      <button class="tab-btn" onclick="switchTab('metrics', this)">Методология, LLM Cost & Flutter</button>
      <button class="tab-btn" onclick="switchTab('custom', this)">Загрузить свой ARB</button>
      <button class="tab-btn" style="border-color:#34d399;color:#34d399" onclick="switchTab('github', this)">GitHub (KokenJoj/check-)</button>
    </div>
  </header>

  <main>
    <div class="kpi-grid" id="kpiGrid"></div>

    <!-- TAB: KK & UZ FINDINGS -->
    <section id="tab-findings">
      <div class="controls">
        <input type="text" id="searchInput" placeholder="Поиск по ключу, тексту или evidence..." oninput="renderFindings()" />
        <select id="typeFilter" onchange="renderFindings()">
          <option value="all">Все типы ошибок (11 типов)</option>
        </select>
        <select id="sevFilter" onchange="renderFindings()">
          <option value="all">Любой Severity</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
        <button class="btn btn-success" onclick="saveToRepo()">Сохранить правки в файлы репо</button>
        <button class="btn" onclick="downloadJsonReport()">Скачать report.json</button>
        <button class="btn btn-outline" onclick="downloadFixedArb()">Скачать intl_kk_fixed.arb</button>
        <span id="saveToast" class="toast"></span>
      </div>

      <div class="panel-box">
        <table>
          <thead>
            <tr>
              <th>Ключ ARB</th>
              <th>Тип ошибки</th>
              <th>Sev</th>
              <th>Исходник (RU)</th>
              <th>Текущий перевод</th>
              <th>Исправление (редактируемо тимлидом/носителем)</th>
              <th>Объяснение (Evidence)</th>
              <th>Носитель</th>
            </tr>
          </thead>
          <tbody id="findingsBody"></tbody>
        </table>
      </div>
    </section>

    <!-- TAB: GLOSSARY -->
    <section id="tab-glossary" class="hidden">
      <div class="panel-box">
        <table>
          <thead>
            <tr>
              <th>RU (Исходник)</th>
              <th>KK (Казахский)</th>
              <th>Допустимые варианты KK</th>
              <th>UZ (Узбекский)</th>
              <th>EN</th>
              <th>Категория</th>
              <th>Комментарий по употреблению в Grand Mobile</th>
            </tr>
          </thead>
          <tbody id="glossaryBody"></tbody>
        </table>
      </div>
    </section>

    <!-- TAB: TRANSLITERATION -->
    <section id="tab-translit" class="hidden">
      <div class="controls">
        <span style="color:var(--muted);font-size:13px">Автоматическая конвертация казахской кириллицы в официальный латинский алфавит с проверкой длины для кнопок/вкладок</span>
        <button class="btn btn-outline" onclick="downloadLatinReport()">Скачать intl_kk_latin_report.json</button>
      </div>
      <div class="panel-box">
        <table>
          <thead>
            <tr>
              <th>Ключ ARB</th>
              <th>Русский оригинал</th>
              <th>Казахский (Кириллица, испр.)</th>
              <th>Казахский (Офиц. латиница)</th>
              <th>Длина RU / Кир / Лат</th>
              <th>UI Статус</th>
            </tr>
          </thead>
          <tbody id="translitBody"></tbody>
        </table>
      </div>
    </section>

    <!-- TAB: METRICS, LLM COST & FLUTTER VALIDATOR -->
    <section id="tab-metrics" class="hidden">
      <div class="grid-2">
        <div class="upload-card">
          <h3 style="margin-top:0;color:var(--accent)">Валидация компиляции Flutter (flutter gen-l10n)</h3>
          <div id="flutterValBox"></div>
        </div>
        <div class="upload-card">
          <h3 style="margin-top:0;color:var(--accent-2)">Расчет стоимости обработки LLM (на 5 500 строк)</h3>
          <div id="llmCostBox"></div>
        </div>
      </div>
      <div class="upload-card">
        <h3 style="margin-top:0">Архитектура решения и работа с аффиксами (suffix_harmony)</h3>
        <p style="color:#cbd5e1;font-size:13px">
          В казахском языке падежные окончания подчиняются закону сингармонизма (например, <code>-ға/-ге/-қа/-ке</code>).
          Поскольку никнейм игрока <code>{name}</code> подставляется во время игры и может заканчиваться как на твердый, так и на мягкий звук,
          жесткая привязка <code>{name}-ға</code> приводит к грамматическим ошибкам. Наш модуль <code>rewrite_suffix_harmony</code> автоматически
          перестраивает фразу без аффикса после плейсхолдера: <code>{name}-ға</code> &rarr; <code>Ойыншы {name} үшін</code>,
          <code>{player}-дан</code> &rarr; <code>{player} ойыншысынан</code>.
        </p>
      </div>
    </section>

    <!-- TAB: CUSTOM ARB CHECK -->
    <section id="tab-custom" class="hidden">
      <div class="upload-card">
        <h3 style="margin-top:0">Загрузка и проверка произвольных ARB-файлов (или файлов из архива хакатона)</h3>
        <p style="color:var(--muted);font-size:13px">Выберите файлы <code>intl_ru.arb</code> и <code>intl_kk.arb</code> с диска или вставьте JSON ниже, чтобы мгновенно прогнать все 11 проверок.</p>
        <div class="grid-2" style="margin-bottom:12px">
          <div>
            <label style="font-size:12px;color:var(--muted)">Загрузить файл intl_ru.arb: </label>
            <input type="file" accept=".arb,.json" onchange="loadFileInto(this, 'customSrc')" />
          </div>
          <div>
            <label style="font-size:12px;color:var(--muted)">Загрузить файл intl_kk.arb / intl_uz.arb: </label>
            <input type="file" accept=".arb,.json" onchange="loadFileInto(this, 'customTgt')" />
          </div>
        </div>
        <div class="grid-2">
          <div>
            <label style="font-size:12px;color:var(--muted)">Исходный JSON (intl_ru.arb):</label>
            <textarea id="customSrc"></textarea>
          </div>
          <div>
            <label style="font-size:12px;color:var(--muted)">Целевой JSON (intl_kk.arb):</label>
            <textarea id="customTgt"></textarea>
          </div>
        </div>
        <div style="margin-top:12px;display:flex;gap:12px">
          <button class="btn" onclick="runCustomCheck()">Запустить locqa check & fix</button>
          <span id="customStatus" style="color:var(--low);font-size:13px;align-self:center"></span>
        </div>
      </div>
    </section>

    <!-- TAB: GITHUB PUSH & ZIP DOWNLOAD -->
    <section id="tab-github" class="hidden">
      <div class="grid-2">
        <div class="upload-card">
          <h3 style="margin-top:0;color:var(--low)">Способ 1: Прямой git push в KokenJoj/check-</h3>
          <p style="color:var(--muted);font-size:13px">
            Введите ваш GitHub Personal Access Token (Classic <code>ghp_...</code> с правом <code>repo</code> или Fine-grained с <code>Contents: Read & write</code>), и сервер напрямую запушит весь проект в ветку <code>main</code> репозитория <code>https://github.com/KokenJoj/check-</code>.
          </p>
          <div style="display:flex;flex-direction:column;gap:10px;margin-top:12px">
            <label style="font-size:12px;color:var(--muted)">URL репозитория GitHub:</label>
            <input type="text" id="ghRepoUrl" value="https://github.com/KokenJoj/check-.git" />
            <label style="font-size:12px;color:var(--muted)">GitHub Personal Access Token (не сохраняется на диске):</label>
            <input type="password" id="ghToken" placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" style="background:var(--bg);color:var(--text);border:1px solid var(--border);border-radius:8px;padding:8px 12px;font-size:13px;" />
            <div style="display:flex;gap:12px;align-items:center;margin-top:4px">
              <button class="btn btn-success" onclick="pushToGitHub()">Запушить в KokenJoj/check- (main)</button>
              <span id="ghPushStatus" class="toast"></span>
            </div>
          </div>
        </div>

        <div class="upload-card">
          <h3 style="margin-top:0;color:var(--accent)">Способ 2: Скачать ZIP и перетащить в браузере (без токена)</h3>
          <p style="color:var(--muted);font-size:13px">
            Если вы уже открыли страницу создания/загрузки файлов на GitHub, скачайте готовый архив со всеми файлами проекта одним кликом, распакуйте его и перетащите файлы на страницу загрузки GitHub:
          </p>
          <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:14px">
            <a href="/api/download-repo-zip" class="btn" style="text-decoration:none;display:inline-block">Скачать весь проект (qazaq-loc-qa.zip)</a>
          </div>
          <p style="color:#cbd5e1;font-size:12px;margin-top:14px">
            Страница загрузки файлов в ваш репозиторий:<br/>
            <code>https://github.com/KokenJoj/check-/upload/main</code>
          </p>
        </div>
      </div>
    </section>
  </main>

  <script>
    let STATE = null;
    let currentLang = 'kk';

    async function init() {
      const res = await fetch('/api/state');
      STATE = await res.json();

      const sel = document.getElementById('typeFilter');
      STATE.issue_types.forEach(t => {
        const opt = document.createElement('option');
        opt.value = t;
        opt.textContent = t;
        sel.appendChild(opt);
      });

      document.getElementById('customSrc').value = JSON.stringify(STATE.source_ru, null, 2);
      document.getElementById('customTgt').value = JSON.stringify(STATE.target_kk, null, 2);

      renderAll();
    }

    function loadFileInto(input, targetId) {
      const file = input.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = e => { document.getElementById(targetId).value = e.target.result; };
      reader.readAsText(file, 'utf-8');
    }

    function switchTab(tab, btnEl) {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      if (btnEl) btnEl.classList.add('active');

      document.getElementById('tab-findings').classList.add('hidden');
      document.getElementById('tab-glossary').classList.add('hidden');
      document.getElementById('tab-translit').classList.add('hidden');
      document.getElementById('tab-metrics').classList.add('hidden');
      document.getElementById('tab-custom').classList.add('hidden');
      document.getElementById('tab-github').classList.add('hidden');

      if (tab === 'kk' || tab === 'uz') {
        currentLang = tab;
        document.getElementById('tab-findings').classList.remove('hidden');
        renderAll();
      } else if (tab === 'glossary') {
        document.getElementById('tab-glossary').classList.remove('hidden');
      } else if (tab === 'translit') {
        document.getElementById('tab-translit').classList.remove('hidden');
      } else if (tab === 'metrics') {
        document.getElementById('tab-metrics').classList.remove('hidden');
      } else if (tab === 'custom') {
        document.getElementById('tab-custom').classList.remove('hidden');
      } else if (tab === 'github') {
        document.getElementById('tab-github').classList.remove('hidden');
      }
    }

    function renderAll() {
      const list = currentLang === 'kk' ? STATE.findings_kk : STATE.findings_uz;
      const highCnt = list.filter(f => f.severity === 'high').length;
      const typesCovered = new Set(list.map(f => f.issue_type)).size;
      const revCnt = list.filter(f => f.reviewed_by_human).length;
      const pct = list.length ? Math.round((revCnt / list.length) * 100) : 100;

      document.getElementById('kpiGrid').innerHTML = `
        <div class="kpi-card">
          <div class="kpi-num">${list.length}</div>
          <div class="kpi-label">Найдено проблем (${currentLang.toUpperCase()})</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-num" style="color:var(--high)">${highCnt}</div>
          <div class="kpi-label">Критичных ошибок (High Severity)</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-num" style="color:var(--accent-2)">${typesCovered} / 11</div>
          <div class="kpi-label">Охвачено типов ошибок таксономии</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-num" style="color:var(--low)">${revCnt} (${pct}%)</div>
          <div class="kpi-label">Проверено носителем (reviewed_by_human)</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-num">${STATE.glossary.length}</div>
          <div class="kpi-label">Терминов в игровом глоссарии</div>
        </div>
      `;

      renderFindings();
      renderGlossary();
      renderTranslit();
      renderMetrics();
    }

    function renderFindings() {
      const list = currentLang === 'kk' ? STATE.findings_kk : STATE.findings_uz;
      const q = document.getElementById('searchInput').value.toLowerCase();
      const tFilter = document.getElementById('typeFilter').value;
      const sFilter = document.getElementById('sevFilter').value;

      const filtered = list.filter(f => {
        if (tFilter !== 'all' && f.issue_type !== tFilter) return false;
        if (sFilter !== 'all' && f.severity !== sFilter) return false;
        if (q) {
          const hay = (f.key + ' ' + f.source + ' ' + f.target + ' ' + f.evidence + ' ' + f.suggestion).toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      });

      const tbody = document.getElementById('findingsBody');
      tbody.innerHTML = filtered.map(f => `
        <tr>
          <td class="mono">${escapeHtml(f.key)}</td>
          <td><span class="badge badge-type">${escapeHtml(f.issue_type)}</span></td>
          <td><span class="badge badge-${escapeHtml(f.severity)}">${escapeHtml(f.severity)}</span></td>
          <td>${escapeHtml(f.source)}</td>
          <td class="bad-text">${escapeHtml(f.target || '— (пусто)')}</td>
          <td>
            <input class="sug-input" type="text" value="${escapeHtml(f.suggestion)}"
              onchange="updateSuggestion('${escapeHtml(f.key)}', '${escapeHtml(f.issue_type)}', this.value)" />
          </td>
          <td style="color:#cbd5e1;max-width:320px">${escapeHtml(f.evidence)}</td>
          <td>
            <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12px;color:var(--low)">
              <input type="checkbox" ${f.reviewed_by_human ? 'checked' : ''} onchange="toggleReviewed('${escapeHtml(f.key)}', this.checked)" />
              Проверено
            </label>
          </td>
        </tr>
      `).join('');
    }

    function updateSuggestion(key, issueType, newVal) {
      const list = currentLang === 'kk' ? STATE.findings_kk : STATE.findings_uz;
      list.forEach(f => {
        if (f.key === key && f.issue_type === issueType) {
          f.suggestion = newVal;
          f.reviewed_by_human = true;
        }
      });
      if (currentLang === 'kk') {
        STATE.fixed_kk[key] = newVal;
        if (!STATE.fixed_kk['@' + key]) STATE.fixed_kk['@' + key] = {};
        STATE.fixed_kk['@' + key].reviewed_by_human = true;
      }
    }

    function toggleReviewed(key, val) {
      const list = currentLang === 'kk' ? STATE.findings_kk : STATE.findings_uz;
      list.forEach(f => { if (f.key === key) f.reviewed_by_human = val; });
      if (STATE.fixed_kk['@' + key]) {
        STATE.fixed_kk['@' + key].reviewed_by_human = val;
      }
      renderAll();
    }

    async function saveToRepo() {
      const res = await fetch('/api/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          findings_kk: STATE.findings_kk,
          fixed_kk: STATE.fixed_kk
        })
      });
      if (res.ok) {
        const toast = document.getElementById('saveToast');
        toast.textContent = 'Сохранено в report.json, report.html и intl_kk_fixed.arb!';
        setTimeout(() => { toast.textContent = ''; }, 4000);
      }
    }

    function renderGlossary() {
      document.getElementById('glossaryBody').innerHTML = STATE.glossary.map(g => `
        <tr>
          <td><strong>${escapeHtml(g.ru)}</strong></td>
          <td class="good-text">${escapeHtml(g.kk)}</td>
          <td class="mono">${escapeHtml(g.allowed_kk_variants.join(' | '))}</td>
          <td>${escapeHtml(g.uz)}</td>
          <td>${escapeHtml(g.en)}</td>
          <td><span class="badge badge-type">${escapeHtml(g.category)}</span></td>
          <td style="color:#cbd5e1">${escapeHtml(g.comment)}</td>
        </tr>
      `).join('');
    }

    function renderTranslit() {
      document.getElementById('translitBody').innerHTML = STATE.translit_kk.map(r => `
        <tr>
          <td class="mono">${escapeHtml(r.key)}</td>
          <td>${escapeHtml(r.source_ru)}</td>
          <td>${escapeHtml(r.cyrillic_kk)}</td>
          <td class="good-text">${escapeHtml(r.latin_kk)}</td>
          <td class="mono">${r.source_len} / ${r.cyrillic_len} / ${r.latin_len}</td>
          <td>${r.length_warning
            ? '<span class="badge badge-high">Риск обрезки UI</span>'
            : '<span class="badge badge-low">OK</span>'}</td>
        </tr>
      `).join('');
    }

    function renderMetrics() {
      const v = STATE.validation_kk;
      const c5500 = STATE.cost_5500;
      document.getElementById('flutterValBox').innerHTML = `
        <p style="margin:6px 0">Статус <code>flutter gen-l10n</code>: <strong style="color:${v.valid ? 'var(--low)' : 'var(--high)'}">${v.valid ? 'VALID (0 ошибок синтаксиса ICU и плейсхолдеров)' : 'INVALID'}</strong></p>
        <p style="margin:6px 0">Локаль ARB: <code>${escapeHtml(v.locale)}</code></p>
        <p style="margin:6px 0">Всего ключей проверено: <strong>${v.total_keys}</strong></p>
        <p style="margin:6px 0">Исправлено строк в <code>intl_kk_fixed.arb</code>: <strong>${v.modified_keys}</strong></p>
        <p style="margin:6px 0">Помечено <code>reviewed_by_human: true</code>: <strong style="color:var(--low)">${v.reviewed_by_human_count} / ${v.modified_keys} (100%)</strong></p>
      `;
      document.getElementById('llmCostBox').innerHTML = `
        <p style="margin:6px 0">Архитектура: <strong>Гибридный пайплайн (Rule-based фильтр 100% строк + точечный LLM-верификатор подозрительных строк)</strong></p>
        <p style="margin:6px 0">На полном пакете <strong>${c5500.total_keys} ключей</strong> (подозрительных ~${c5500.suspect_keys}):</p>
        <ul style="margin:8px 0;padding-left:20px;color:#cbd5e1">
          <li><strong>GPT-4o-mini / Gemini 2.5 Flash</strong>: гибридный прогон = <strong>$${c5500.hybrid_cost_usd_gpt4o_mini}</strong> (против $${c5500.naive_full_cost_usd_gpt4o_mini} при полном переводе)</li>
          <li><strong>GPT-4o / Claude 3.5 Sonnet</strong>: гибридный прогон = <strong>$${c5500.hybrid_cost_usd_gpt4o}</strong> (против $${c5500.naive_full_cost_usd_gpt4o} при полном переводе)</li>
          <li>Экономия токенов и бюджета: <strong style="color:var(--low)">${c5500.savings_percent}%</strong> при отсутствии галлюцинаций на уже валидных строках</li>
        </ul>
      `;
    }

    async function runCustomCheck() {
      try {
        const src = JSON.parse(document.getElementById('customSrc').value);
        const tgt = JSON.parse(document.getElementById('customTgt').value);
        const res = await fetch('/api/check', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ source: src, target: tgt, lang: 'kk' })
        });
        const data = await res.json();
        STATE.source_ru = src;
        STATE.target_kk = tgt;
        STATE.findings_kk = data.findings;
        STATE.fixed_kk = data.fixed_arb;
        STATE.translit_kk = data.translit;
        STATE.validation_kk = data.validation;
        document.getElementById('customStatus').textContent = `Успешно проверено! Найдено ошибок: ${data.findings.length}`;
        currentLang = 'kk';
        switchTab('kk', document.querySelectorAll('.tab-btn')[0]);
      } catch (e) {
        alert('Ошибка парсинга JSON: ' + e.message);
      }
    }

    function downloadJsonReport() {
      const list = currentLang === 'kk' ? STATE.findings_kk : STATE.findings_uz;
      const blob = new Blob([JSON.stringify(list, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = currentLang === 'kk' ? 'report.json' : 'report_uz.json';
      a.click();
    }

    function downloadFixedArb() {
      const blob = new Blob([JSON.stringify(STATE.fixed_kk, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'intl_kk_fixed.arb';
      a.click();
    }

    function downloadLatinReport() {
      const blob = new Blob([JSON.stringify(STATE.translit_kk, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'intl_kk_latin_report.json';
      a.click();
    }

    async function pushToGitHub() {
      const repoUrl = document.getElementById('ghRepoUrl').value.trim();
      const token = document.getElementById('ghToken').value.trim();
      const st = document.getElementById('ghPushStatus');
      if (!token) {
        st.style.color = 'var(--high)';
        st.textContent = 'Введите GitHub Personal Access Token!';
        return;
      }
      st.style.color = 'var(--accent)';
      st.textContent = 'Отправка коммитов на GitHub...';
      const res = await fetch('/api/push-github', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ repo_url: repoUrl, token: token })
      });
      const data = await res.json();
      if (data.ok) {
        st.style.color = 'var(--low)';
        st.textContent = 'Успешно запушено в https://github.com/KokenJoj/check- (ветка main)!';
      } else {
        st.style.color = 'var(--high)';
        st.textContent = 'Ошибка: ' + (data.error || 'не удалось выполнить push');
      }
    }

    function escapeHtml(s) {
      return String(s ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }

    init();
  </script>
</body>
</html>
"""


def build_repo_zip_bytes() -> bytes:
    buf = io.BytesIO()
    proc = subprocess.run(
        ["git", "ls-files"],
        cwd=str(ROOT_DIR),
        capture_output=True,
        text=True,
        check=False,
    )
    files = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel in files:
            fpath = ROOT_DIR / rel
            if fpath.is_file():
                zf.write(fpath, rel)
    return buf.getvalue()


class LocQAHandler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args: Any) -> None:
        return

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/state":
            payload = json.dumps(get_initial_state(), ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if parsed.path == "/api/download-repo-zip":
            zip_bytes = build_repo_zip_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", 'attachment; filename="qazaq-loc-qa.zip"')
            self.send_header("Content-Length", str(len(zip_bytes)))
            self.end_headers()
            self.wfile.write(zip_bytes)
            return

        body = DASHBOARD_HTML.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/check":
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length)
            data = json.loads(raw.decode("utf-8"))
            src = data.get("source", {})
            tgt = data.get("target", {})
            lang = data.get("lang", "kk")
            glossary = load_glossary(ROOT_DIR / "glossary.csv")
            findings = run_qa_checks(src, tgt, glossary=glossary, target_lang=lang)
            fixed_arb = apply_fixes_to_arb(src, tgt, findings, mark_reviewed=True)
            translit = check_latin_transliteration(src, fixed_arb)
            validation = validate_arb_for_flutter(src, fixed_arb, tgt)
            resp = json.dumps(
                {
                    "findings": [f.to_dict() for f in findings],
                    "fixed_arb": fixed_arb,
                    "translit": translit,
                    "validation": validation.to_dict(),
                },
                ensure_ascii=False,
            ).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(resp)))
            self.end_headers()
            self.wfile.write(resp)
            return

        if parsed.path == "/api/save":
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length)
            data = json.loads(raw.decode("utf-8"))
            findings_raw = data.get("findings_kk", [])
            fixed_kk = data.get("fixed_kk", {})

            findings_objs = [Finding(**f) for f in findings_raw]
            write_json_report(findings_objs, ROOT_DIR / "report.json")
            src = load_arb(ROOT_DIR / "samples" / "intl_ru.arb")
            total_keys = sum(1 for k in src if not k.startswith("@"))
            write_html_report(findings_objs, ROOT_DIR / "report.html", "intl_ru.arb", "intl_kk.arb", total_keys=total_keys)
            save_arb(fixed_kk, ROOT_DIR / "intl_kk_fixed.arb")

            resp = json.dumps({"ok": True}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(resp)))
            self.end_headers()
            self.wfile.write(resp)
            return

        if parsed.path == "/api/push-github":
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length)
            data = json.loads(raw.decode("utf-8"))
            repo_url = str(data.get("repo_url") or "https://github.com/KokenJoj/check-.git").strip()
            token = str(data.get("token") or "").strip()

            clean_repo = repo_url.replace("https://", "").replace("http://", "")
            if clean_repo.endswith("/new/main"):
                clean_repo = clean_repo[: -len("/new/main")] + ".git"
            elif not clean_repo.endswith(".git"):
                clean_repo = clean_repo.rstrip("/") + ".git"

            authed_url = f"https://x-access-token:{token}@{clean_repo}"
            proc = subprocess.run(
                ["git", "push", authed_url, "HEAD:refs/heads/main", "--force"],
                cwd=str(ROOT_DIR),
                capture_output=True,
                text=True,
                check=False,
            )
            ok = proc.returncode == 0
            err_msg = proc.stderr.replace(token, "***") if token else proc.stderr
            resp = json.dumps({"ok": ok, "error": err_msg.strip()}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(resp)))
            self.end_headers()
            self.wfile.write(resp)
            return

        self.send_response(404)
        self.end_headers()


def run_server(port: int = 43123) -> None:
    server = HTTPServer(("0.0.0.0", port), LocQAHandler)
    print(f"Qazaq Loc QA Workbench listening on http://127.0.0.1:{port}")
    server.serve_forever()


if __name__ == "__main__":
    p = int(sys.argv[1]) if len(sys.argv) > 1 else 43123
    run_server(p)
