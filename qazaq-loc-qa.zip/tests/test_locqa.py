"""Unit tests for Qazaq Loc QA covering all 11 issue types, schema compliance, validator, LLM cost, and pipeline."""

from __future__ import annotations

import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from locqa.analyzer import (
    ISSUE_TYPES,
    check_latin_transliteration,
    generate_latin_arb,
    load_arb,
    load_glossary,
    run_qa_checks,
)
from locqa.cli import main as cli_main
from locqa.fixer import apply_fixes_to_arb
from locqa.llm import calculate_llm_cost_report
from locqa.translit import transliterate_kk_to_latin
from locqa.validator import validate_arb_for_flutter


class TestLocQA(unittest.TestCase):
    def setUp(self) -> None:
        self.root = Path(__file__).resolve().parent.parent
        self.glossary = load_glossary(self.root / "glossary.csv")
        self.src = load_arb(self.root / "samples" / "intl_ru.arb")
        self.tgt_kk = load_arb(self.root / "samples" / "intl_kk.arb")
        self.tgt_uz = load_arb(self.root / "samples" / "intl_uz.arb")

    def test_all_11_issue_types_detected(self) -> None:
        findings = run_qa_checks(self.src, self.tgt_kk, glossary=self.glossary, target_lang="kk")
        found_types = {f.issue_type for f in findings}
        for expected in ISSUE_TYPES:
            self.assertIn(expected, found_types, f"Expected issue_type '{expected}' to be detected")

    def test_legitimate_same_as_source_ignored(self) -> None:
        findings = run_qa_checks(self.src, self.tgt_kk, glossary=self.glossary, target_lang="kk")
        flagged_keys = {f.key for f in findings if f.issue_type == "same_as_source"}
        self.assertNotIn("app_brand_title", flagged_keys)
        self.assertNotIn("currency_gc_short", flagged_keys)
        self.assertNotIn("hud_payday_badge", flagged_keys)
        self.assertNotIn("vehicle_garage_label", flagged_keys)
        self.assertIn("job_trucker_select", flagged_keys)

    def test_finding_schema_compliance(self) -> None:
        findings = run_qa_checks(self.src, self.tgt_kk, glossary=self.glossary, target_lang="kk")
        required_fields = {
            "key",
            "issue_type",
            "severity",
            "source",
            "target",
            "evidence",
            "suggestion",
            "confidence",
            "reviewed_by_human",
        }
        for f in findings:
            d = f.to_dict()
            self.assertEqual(set(d.keys()), required_fields)
            self.assertIn(d["severity"], ("high", "medium", "low"))
            self.assertIsInstance(d["confidence"], float)
            self.assertIsInstance(d["reviewed_by_human"], bool)

    def test_suffix_harmony_reformulation(self) -> None:
        findings = run_qa_checks(self.src, self.tgt_kk, glossary=self.glossary, target_lang="kk")
        sh = [f for f in findings if f.key == "transfer_money_to_player" and f.issue_type == "suffix_harmony"]
        self.assertEqual(len(sh), 1)
        self.assertNotIn("{name}-ға", sh[0].suggestion)
        self.assertIn("{name}", sh[0].suggestion)

    def test_transliteration_preserves_placeholders_and_generates_arb(self) -> None:
        src_text = "Сіз {name} ойыншысына {amount} ₸ аудардыңыз"
        lat = transliterate_kk_to_latin(src_text)
        self.assertIn("{name}", lat)
        self.assertIn("{amount}", lat)
        lat_arb = generate_latin_arb(self.tgt_kk)
        self.assertEqual(lat_arb["@@locale"], "kk_Latn")

    def test_fixer_and_flutter_validator(self) -> None:
        findings = run_qa_checks(self.src, self.tgt_kk, glossary=self.glossary, target_lang="kk")
        fixed = apply_fixes_to_arb(self.src, self.tgt_kk, findings, mark_reviewed=True)
        self.assertEqual(fixed["garage_rent_button"], "Жалға алу")
        self.assertTrue(fixed["@garage_rent_button"]["reviewed_by_human"])

        val = validate_arb_for_flutter(self.src, fixed, self.tgt_kk)
        self.assertTrue(val.valid, f"Expected valid Flutter ARB, got errors: {val.errors}")
        self.assertEqual(val.unreviewed_modified_keys, [])

    def test_llm_cost_calculator(self) -> None:
        findings = run_qa_checks(self.src, self.tgt_kk, glossary=self.glossary, target_lang="kk")
        cost = calculate_llm_cost_report(self.src, findings, model="gpt-4o-mini")
        self.assertGreater(cost.total_arb_keys, 20)
        self.assertGreater(cost.full_retranslation_cost_usd, 0)
        self.assertGreaterEqual(cost.estimated_cost_usd, 0)

    def test_cli_check_fix_validate_and_zip_pipeline(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_p = Path(tmp)
            # Create a simulated hack-*.zip archive with ARB files
            zip_path = tmp_p / "hack-4e892c51-sharkmove.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.write(self.root / "samples" / "intl_ru.arb", "intl_ru.arb")
                zf.write(self.root / "samples" / "intl_kk.arb", "intl_kk.arb")
                zf.write(self.root / "samples" / "intl_uz.arb", "intl_uz.arb")

            out_dir = tmp_p / "out"
            rc = cli_main([
                "pipeline",
                "--input", str(zip_path),
                "--glossary", str(self.root / "glossary.csv"),
                "--out-dir", str(out_dir),
            ])
            self.assertEqual(rc, 0)
            self.assertTrue((out_dir / "report.json").exists())
            self.assertTrue((out_dir / "report.html").exists())
            self.assertTrue((out_dir / "intl_kk_fixed.arb").exists())
            self.assertTrue((out_dir / "report_uz.json").exists())
            self.assertTrue((out_dir / "intl_uz_fixed.arb").exists())
            self.assertTrue((out_dir / "intl_kk_latin.arb").exists())
            self.assertTrue((out_dir / "metrics_summary.json").exists())

    def test_uzbek_bonus_analysis(self) -> None:
        findings_uz = run_qa_checks(self.src, self.tgt_uz, glossary=self.glossary, target_lang="uz")
        uz_types = {f.issue_type for f in findings_uz}
        self.assertIn("untranslated", uz_types)
        self.assertIn("same_as_source", uz_types)
        self.assertIn("placeholder_mismatch", uz_types)
        self.assertIn("length_overflow", uz_types)


if __name__ == "__main__":
    unittest.main()
